#![cfg_attr(
    all(not(debug_assertions), target_os = "windows"),
    windows_subsystem = "windows"
)]

use rusqlite::{params, Connection};
use serde::{Deserialize, Serialize};
use std::sync::Mutex;
use tauri::api::http::{ClientBuilder, HttpRequestBuilder, ResponseType};
use tauri::Manager;
use tauri::State;
use uuid::Uuid;

// Versão instalada deste aplicativo. Atualize este número sempre que uma nova leva
// de arquivos (frontend e/ou backend) for entregue, para bater com o "versao" publicado
// em https://github.com/wallas24/prontuario-updates/blob/main/versao.json
const VERSAO_ATUAL: &str = "1.10.3";
const URL_VERSAO_REMOTA: &str =
    "https://raw.githubusercontent.com/wallas24/prontuario-updates/main/versao.json";

// ---------- Estruturas de dados ----------

#[derive(Serialize, Deserialize, Clone)]
struct Patient {
    id: String,
    nome: String,
    telefone: String,
    telefone2: String,
    documento: String,
    data_nascimento: String,
    endereco: String,
    numero: String,
    complemento: String,
    bairro: String,
    municipio: String,
    uf: String,
    sexo: String,
    profissao: String,
    observacoes: String,
    criado_em: String,
    atualizado_em: String,
    favorito: bool,
    tags: String,
    observacao_fixa: String,
    whatsapp: bool,
}

#[derive(Serialize, Deserialize, Clone)]
struct PatientListItem {
    id: String,
    nome: String,
    telefone: String,
    ultima_consulta: Option<String>,
    favorito: bool,
    tags: String,
    data_nascimento: String,
    tem_obs: bool,
}

#[derive(Serialize)]
struct TagContagem {
    nome: String,
    total: i64,
}

#[derive(Serialize, Deserialize, Clone)]
struct Visit {
    id: String,
    paciente_id: String,
    data: String,
    primeira_consulta: String,
    tipo_atendimento: String,
    hpp: String,
    historia_familiar: String,
    alergias: String,
    medicacao_uso: String,
    exame_fisico: String,
    frequencia_cardiaca: String,
    pressao_sistolica: String,
    pressao_diastolica: String,
    pressao_arterial_media: String,
    frequencia_respiratoria: String,
    saturacao_o2: String,
    temperatura: String,
    glicemia: String,
    momento_coleta: String,
    sinais_vitais_obs: String,
    cid: String,
    diagnostico_atual: String,
    diagnostico_previo: String,
    resultado_exames: String,
    conduta: String,
    criado_em: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct VisitListItem {
    id: String,
    data: String,
    resumo: String,
    tipo_atendimento: String,
    trecho: String,
    queixa: String,
    conduta: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct ExameEvolucao {
    id: String,
    nome_exame: String,
    data: String,
    resultado: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct MedicoConfig {
    nome: String,
    crm: String,
    rqe: String,
    especialidade: String,
    endereco: String,
    telefone: String,
    celular: String,
    cidade: String,
    uf: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct DocumentoGerado {
    id: String,
    tipo: String,
    conteudo: String,
    atualizado_em: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct ModeloDocumento {
    id: String,
    nome: String,
    conteudo: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct Resumo {
    total_pacientes: i64,
    atendimentos_semana: i64,
    atendidos_hoje: i64,
    urgencias_hoje: i64,
}

#[derive(Serialize, Deserialize, Clone)]
struct AtendimentoRecente {
    atendimento_id: String,
    paciente_id: String,
    paciente_nome: String,
    data: String,
    tipo_atendimento: String,
    queixa: String,
    diagnostico: String,
    trecho: String,
}

#[derive(Serialize, Deserialize, Clone)]
struct DadosRecorrentes {
    hpp: String,
    historia_familiar: String,
    alergias: String,
    medicacao_uso: String,
    diagnostico_previo: String,
}

struct DbState(Mutex<Connection>);

// ---------- Inicialização do banco ----------

fn init_db(conn: &Connection) {
    conn.execute(
        "CREATE TABLE IF NOT EXISTS pacientes (
            id TEXT PRIMARY KEY,
            nome TEXT NOT NULL,
            telefone TEXT,
            documento TEXT,
            data_nascimento TEXT,
            endereco TEXT,
            profissao TEXT,
            observacoes TEXT,
            criado_em TEXT NOT NULL,
            atualizado_em TEXT
        )",
        [],
    )
    .expect("erro ao criar tabela pacientes");

    // Migração leve: adiciona colunas que podem faltar em bancos já existentes
    // (ignora o erro caso a coluna já exista)
    let _ = conn.execute("ALTER TABLE pacientes ADD COLUMN profissao TEXT", []);
    let _ = conn.execute("ALTER TABLE pacientes ADD COLUMN atualizado_em TEXT", []);
    let _ = conn.execute("ALTER TABLE pacientes ADD COLUMN favorito INTEGER DEFAULT 0", []);
    for coluna in ["telefone2", "numero", "complemento", "bairro", "municipio", "uf", "sexo", "tags", "observacao_fixa", "whatsapp"] {
        let _ = conn.execute(
            &format!("ALTER TABLE pacientes ADD COLUMN {} TEXT DEFAULT ''", coluna),
            [],
        );
    }

    conn.execute(
        "CREATE TABLE IF NOT EXISTS atendimentos (
            id TEXT PRIMARY KEY,
            paciente_id TEXT NOT NULL,
            data TEXT NOT NULL,
            primeira_consulta TEXT,
            hpp TEXT,
            historia_familiar TEXT,
            alergias TEXT,
            medicacao_uso TEXT,
            exame_fisico TEXT,
            diagnostico_atual TEXT,
            diagnostico_previo TEXT,
            resultado_exames TEXT,
            conduta TEXT,
            criado_em TEXT NOT NULL,
            FOREIGN KEY(paciente_id) REFERENCES pacientes(id)
        )",
        [],
    )
    .expect("erro ao criar tabela atendimentos");

    // Migração leve: adiciona coluna que pode faltar em bancos já existentes
    let _ = conn.execute("ALTER TABLE atendimentos ADD COLUMN primeira_consulta TEXT", []);
    let _ = conn.execute("ALTER TABLE atendimentos ADD COLUMN tipo_atendimento TEXT DEFAULT ''", []);
    let _ = conn.execute("ALTER TABLE atendimentos ADD COLUMN queixa_principal TEXT DEFAULT ''", []);
    for coluna in [
        "frequencia_cardiaca",
        "pressao_sistolica",
        "pressao_diastolica",
        "pressao_arterial_media",
        "frequencia_respiratoria",
        "saturacao_o2",
        "temperatura",
        "glicemia",
        "momento_coleta",
        "sinais_vitais_obs",
        "cid",
    ] {
        let _ = conn.execute(
            &format!("ALTER TABLE atendimentos ADD COLUMN {} TEXT DEFAULT ''", coluna),
            [],
        );
    }

    conn.execute(
        "CREATE TABLE IF NOT EXISTS exames_evolucao (
            id TEXT PRIMARY KEY,
            paciente_id TEXT NOT NULL,
            nome_exame TEXT NOT NULL,
            data TEXT NOT NULL,
            resultado TEXT NOT NULL,
            criado_em TEXT NOT NULL,
            FOREIGN KEY(paciente_id) REFERENCES pacientes(id)
        )",
        [],
    )
    .expect("erro ao criar tabela exames_evolucao");

    conn.execute(
        "CREATE TABLE IF NOT EXISTS medico_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            nome TEXT NOT NULL DEFAULT '',
            crm TEXT NOT NULL DEFAULT '',
            especialidade TEXT NOT NULL DEFAULT ''
        )",
        [],
    )
    .expect("erro ao criar tabela medico_config");

    // Migração: colunas novas (endereço, telefone, cidade, UF) para bancos já existentes
    for coluna in ["endereco", "telefone", "cidade", "uf", "rqe", "celular"] {
        let _ = conn.execute(
            &format!("ALTER TABLE medico_config ADD COLUMN {} TEXT NOT NULL DEFAULT ''", coluna),
            [],
        );
    }

    conn.execute(
        "CREATE TABLE IF NOT EXISTS modelos_documento (
            id TEXT PRIMARY KEY,
            tipo_documento TEXT NOT NULL,
            nome TEXT NOT NULL,
            conteudo TEXT NOT NULL,
            criado_em TEXT NOT NULL
        )",
        [],
    )
    .expect("erro ao criar tabela modelos_documento");

    conn.execute(
        "CREATE TABLE IF NOT EXISTS documentos_gerados (
            id TEXT PRIMARY KEY,
            paciente_id TEXT NOT NULL,
            tipo TEXT NOT NULL,
            conteudo TEXT NOT NULL,
            criado_em TEXT NOT NULL,
            atualizado_em TEXT NOT NULL
        )",
        [],
    )
    .expect("erro ao criar tabela documentos_gerados");

    conn.execute(
        "CREATE TABLE IF NOT EXISTS auth_config (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            senha_hash TEXT NOT NULL,
            pergunta_seguranca TEXT NOT NULL,
            resposta_hash TEXT NOT NULL
        )",
        [],
    )
    .expect("erro ao criar tabela auth_config");
}

// ---------- Comandos: Relatórios ----------

#[derive(Serialize, Deserialize, Clone)]
struct DocumentoRelatorio {
    tipo: String,
    data: String,
    paciente_nome: String,
}

#[tauri::command]
fn list_documentos_periodo(state: State<DbState>, inicio: String, fim: String) -> Result<Vec<DocumentoRelatorio>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let inicio_completo = format!("{}T00:00:00", inicio);
    let fim_completo = format!("{}T23:59:59", fim);

    let mut stmt = conn
        .prepare(
            "SELECT d.tipo, d.criado_em, p.nome FROM documentos_gerados d
             JOIN pacientes p ON p.id = d.paciente_id
             WHERE d.criado_em >= ?1 AND d.criado_em <= ?2
             ORDER BY d.criado_em DESC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![inicio_completo, fim_completo], |row| {
            Ok(DocumentoRelatorio {
                tipo: row.get(0)?,
                data: row.get(1)?,
                paciente_nome: row.get(2)?,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut lista = Vec::new();
    for r in rows {
        lista.push(r.map_err(|e| e.to_string())?);
    }
    Ok(lista)
}

#[derive(Serialize, Deserialize, Clone)]
struct AtendimentoRelatorio {
    data: String,
    paciente_nome: String,
}

#[tauri::command]
fn list_atendimentos_periodo(state: State<DbState>, inicio: String, fim: String) -> Result<Vec<AtendimentoRelatorio>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let inicio_completo = format!("{} 00:00", inicio);
    let fim_completo = format!("{} 23:59", fim);

    let mut stmt = conn
        .prepare(
            "SELECT a.data, p.nome FROM atendimentos a
             JOIN pacientes p ON p.id = a.paciente_id
             WHERE a.data >= ?1 AND a.data <= ?2
             ORDER BY a.data DESC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![inicio_completo, fim_completo], |row| {
            Ok(AtendimentoRelatorio {
                data: row.get(0)?,
                paciente_nome: row.get(1)?,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut lista = Vec::new();
    for r in rows {
        lista.push(r.map_err(|e| e.to_string())?);
    }
    Ok(lista)
}

#[derive(Serialize, Deserialize, Clone)]
struct PacienteRelatorio {
    nome: String,
    telefone: String,
    sexo: String,
    bairro: String,
    data_nascimento: String,
}

#[tauri::command]
fn list_pacientes_relatorio(state: State<DbState>) -> Result<Vec<PacienteRelatorio>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare("SELECT nome, COALESCE(telefone, ''), COALESCE(sexo, ''), COALESCE(bairro, ''), COALESCE(data_nascimento, '') FROM pacientes")
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map([], |row| {
            Ok(PacienteRelatorio {
                nome: row.get(0)?,
                telefone: row.get(1)?,
                sexo: row.get(2)?,
                bairro: row.get(3)?,
                data_nascimento: row.get(4)?,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut lista = Vec::new();
    for r in rows {
        lista.push(r.map_err(|e| e.to_string())?);
    }
    Ok(lista)
}

// ---------- Comandos: Autenticação ----------

#[tauri::command]
fn auth_configurada(state: State<DbState>) -> Result<bool, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let existe: i64 = conn
        .query_row("SELECT COUNT(*) FROM auth_config WHERE id = 1", [], |row| row.get(0))
        .map_err(|e| e.to_string())?;
    Ok(existe > 0)
}

#[tauri::command]
fn configurar_auth(state: State<DbState>, senha: String, pergunta: String, resposta: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let senha_hash = bcrypt::hash(&senha, bcrypt::DEFAULT_COST).map_err(|e| e.to_string())?;
    let resposta_hash = bcrypt::hash(resposta.trim().to_lowercase(), bcrypt::DEFAULT_COST).map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT OR REPLACE INTO auth_config (id, senha_hash, pergunta_seguranca, resposta_hash) VALUES (1, ?1, ?2, ?3)",
        params![senha_hash, pergunta, resposta_hash],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn verificar_senha(state: State<DbState>, senha: String) -> Result<bool, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let hash: String = conn
        .query_row("SELECT senha_hash FROM auth_config WHERE id = 1", [], |row| row.get(0))
        .map_err(|e| e.to_string())?;
    bcrypt::verify(&senha, &hash).map_err(|e| e.to_string())
}

#[tauri::command]
fn obter_pergunta_seguranca(state: State<DbState>) -> Result<String, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.query_row("SELECT pergunta_seguranca FROM auth_config WHERE id = 1", [], |row| row.get(0))
        .map_err(|e| e.to_string())
}

#[tauri::command]
fn verificar_resposta_seguranca(state: State<DbState>, resposta: String) -> Result<bool, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let hash: String = conn
        .query_row("SELECT resposta_hash FROM auth_config WHERE id = 1", [], |row| row.get(0))
        .map_err(|e| e.to_string())?;
    bcrypt::verify(resposta.trim().to_lowercase(), &hash).map_err(|e| e.to_string())
}

#[tauri::command]
fn redefinir_senha(state: State<DbState>, nova_senha: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let senha_hash = bcrypt::hash(&nova_senha, bcrypt::DEFAULT_COST).map_err(|e| e.to_string())?;
    conn.execute("UPDATE auth_config SET senha_hash = ?1 WHERE id = 1", params![senha_hash])
        .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn alterar_senha(state: State<DbState>, senha_atual: String, nova_senha: String) -> Result<bool, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let hash: String = conn
        .query_row("SELECT senha_hash FROM auth_config WHERE id = 1", [], |row| row.get(0))
        .map_err(|e| e.to_string())?;
    if !bcrypt::verify(&senha_atual, &hash).map_err(|e| e.to_string())? {
        return Ok(false);
    }
    let novo_hash = bcrypt::hash(&nova_senha, bcrypt::DEFAULT_COST).map_err(|e| e.to_string())?;
    conn.execute("UPDATE auth_config SET senha_hash = ?1 WHERE id = 1", params![novo_hash])
        .map_err(|e| e.to_string())?;
    Ok(true)
}

// ---------- Comandos: Pacientes ----------

#[tauri::command]
fn add_patient(
    state: State<DbState>,
    nome: String,
    telefone: String,
    telefone2: String,
    documento: String,
    data_nascimento: String,
    endereco: String,
    numero: String,
    complemento: String,
    bairro: String,
    municipio: String,
    uf: String,
    sexo: String,
    profissao: String,
    observacoes: String,
) -> Result<String, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let id = Uuid::new_v4().to_string();
    let criado_em = chrono::Local::now().to_rfc3339();

    conn.execute(
        "INSERT INTO pacientes (id, nome, telefone, telefone2, documento, data_nascimento, endereco, numero, complemento, bairro, municipio, uf, sexo, profissao, observacoes, criado_em, atualizado_em)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?16)",
        params![id, nome, telefone, telefone2, documento, data_nascimento, endereco, numero, complemento, bairro, municipio, uf, sexo, profissao, observacoes, criado_em],
    )
    .map_err(|e| e.to_string())?;

    Ok(id)
}

#[tauri::command]
fn update_patient(
    state: State<DbState>,
    id: String,
    nome: String,
    telefone: String,
    telefone2: String,
    documento: String,
    data_nascimento: String,
    endereco: String,
    numero: String,
    complemento: String,
    bairro: String,
    municipio: String,
    uf: String,
    sexo: String,
    profissao: String,
    observacoes: String,
) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let atualizado_em = chrono::Local::now().to_rfc3339();
    conn.execute(
        "UPDATE pacientes SET nome=?1, telefone=?2, telefone2=?3, documento=?4, data_nascimento=?5, endereco=?6, numero=?7, complemento=?8, bairro=?9, municipio=?10, uf=?11, sexo=?12, profissao=?13, observacoes=?14, atualizado_em=?15 WHERE id=?16",
        params![nome, telefone, telefone2, documento, data_nascimento, endereco, numero, complemento, bairro, municipio, uf, sexo, profissao, observacoes, atualizado_em, id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn list_patients(state: State<DbState>, busca: Option<String>) -> Result<Vec<PatientListItem>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let termo_nome = format!("%{}%", busca.clone().unwrap_or_default().to_lowercase());
    let termo_doc = format!(
        "%{}%",
        busca
            .unwrap_or_default()
            .to_lowercase()
            .replace('.', "")
            .replace('-', "")
            .replace(' ', "")
            .replace('(', "")
            .replace(')', "")
    );

    let mut stmt = conn
        .prepare(
            "SELECT p.id, p.nome, p.telefone,
                    (SELECT MAX(a.data) FROM atendimentos a WHERE a.paciente_id = p.id) as ultima,
                    COALESCE(p.favorito, 0),
                    COALESCE(p.tags, ''),
                    COALESCE(p.data_nascimento, ''),
                    COALESCE(p.observacao_fixa, '') <> ''
             FROM pacientes p
             WHERE lower(p.nome) LIKE ?1 OR lower(replace(replace(replace(p.documento, '.', ''), '-', ''), ' ', '')) LIKE ?2
                   OR lower(COALESCE(p.tags, '')) LIKE ?1
                   OR lower(replace(replace(replace(replace(replace(COALESCE(p.telefone, ''), '(', ''), ')', ''), '-', ''), ' ', ''), '.', '')) LIKE ?2
                   OR lower(replace(replace(replace(replace(replace(COALESCE(p.telefone2, ''), '(', ''), ')', ''), '-', ''), ' ', ''), '.', '')) LIKE ?2
             ORDER BY COALESCE(p.favorito, 0) DESC, p.nome COLLATE NOCASE ASC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![termo_nome, termo_doc], |row| {
            Ok(PatientListItem {
                id: row.get(0)?,
                nome: row.get(1)?,
                telefone: row.get(2)?,
                ultima_consulta: row.get(3)?,
                favorito: row.get::<_, i64>(4)? != 0,
                tags: row.get(5)?,
                data_nascimento: row.get(6)?,
                tem_obs: row.get::<_, i64>(7)? != 0,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut result = Vec::new();
    for r in rows {
        result.push(r.map_err(|e| e.to_string())?);
    }
    Ok(result)
}

#[tauri::command]
fn get_patient(state: State<DbState>, id: String) -> Result<Patient, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.query_row(
        "SELECT id, nome, telefone, COALESCE(telefone2, ''), documento, data_nascimento, endereco,
                COALESCE(numero, ''), COALESCE(complemento, ''), COALESCE(bairro, ''), COALESCE(municipio, ''), COALESCE(uf, ''),
                COALESCE(sexo, ''), COALESCE(profissao, ''), observacoes, criado_em, COALESCE(atualizado_em, criado_em), COALESCE(favorito, 0), COALESCE(tags, ''), COALESCE(observacao_fixa, ''), COALESCE(whatsapp, '') = '1'
         FROM pacientes WHERE id = ?1",
        params![id],
        |row| {
            Ok(Patient {
                id: row.get(0)?,
                nome: row.get(1)?,
                telefone: row.get(2)?,
                telefone2: row.get(3)?,
                documento: row.get(4)?,
                data_nascimento: row.get(5)?,
                endereco: row.get(6)?,
                numero: row.get(7)?,
                complemento: row.get(8)?,
                bairro: row.get(9)?,
                municipio: row.get(10)?,
                uf: row.get(11)?,
                sexo: row.get(12)?,
                profissao: row.get(13)?,
                observacoes: row.get(14)?,
                criado_em: row.get(15)?,
                atualizado_em: row.get(16)?,
                favorito: row.get::<_, i64>(17)? != 0,
                tags: row.get(18)?,
                observacao_fixa: row.get(19)?,
                whatsapp: row.get::<_, i64>(20)? != 0,
            })
        },
    )
    .map_err(|e| e.to_string())
}

#[tauri::command]
fn set_patient_whatsapp(state: State<DbState>, id: String, ativo: bool) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "UPDATE pacientes SET whatsapp = ?1 WHERE id = ?2",
        params![if ativo { "1" } else { "" }, id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn set_observacao_fixa(state: State<DbState>, id: String, texto: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let limpo: String = texto.trim().chars().take(1000).collect();
    conn.execute(
        "UPDATE pacientes SET observacao_fixa = ?1 WHERE id = ?2",
        params![limpo, id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

// Tags ficam guardadas numa coluna só, separadas por "|" (o frontend remove "|" dos nomes).
fn normalizar_tags(bruto: &str) -> String {
    let mut vistas: Vec<String> = Vec::new();
    for parte in bruto.split('|') {
        let limpa = parte.trim();
        if limpa.is_empty() {
            continue;
        }
        let limpa: String = limpa.chars().take(30).collect();
        if !vistas.iter().any(|t| t.to_lowercase() == limpa.to_lowercase()) {
            vistas.push(limpa);
        }
    }
    vistas.join("|")
}

#[tauri::command]
fn set_patient_tags(state: State<DbState>, id: String, tags: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "UPDATE pacientes SET tags = ?1 WHERE id = ?2",
        params![normalizar_tags(&tags), id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn list_all_tags(state: State<DbState>) -> Result<Vec<TagContagem>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT COALESCE(tags, '') FROM pacientes WHERE COALESCE(tags, '') <> ''")
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([], |row| row.get::<_, String>(0))
        .map_err(|e| e.to_string())?;

    // Conta quantos pacientes têm cada tag (ignorando maiúsculas/minúsculas, mantendo a 1ª grafia)
    let mut contagem: Vec<(String, TagContagem)> = Vec::new();
    for r in rows {
        let linha = r.map_err(|e| e.to_string())?;
        for tag in linha.split('|').filter(|t| !t.is_empty()) {
            let chave = tag.to_lowercase();
            match contagem.iter_mut().find(|(k, _)| *k == chave) {
                Some((_, c)) => c.total += 1,
                None => contagem.push((chave, TagContagem { nome: tag.to_string(), total: 1 })),
            }
        }
    }
    let mut resultado: Vec<TagContagem> = contagem.into_iter().map(|(_, c)| c).collect();
    resultado.sort_by(|a, b| b.total.cmp(&a.total).then(a.nome.to_lowercase().cmp(&b.nome.to_lowercase())));
    Ok(resultado)
}

// ---------- Comandos: Atendimentos ----------

#[tauri::command]
fn add_visit(
    state: State<DbState>,
    paciente_id: String,
    primeira_consulta: String,
    tipo_atendimento: String,
    hpp: String,
    historia_familiar: String,
    alergias: String,
    medicacao_uso: String,
    exame_fisico: String,
    frequencia_cardiaca: String,
    pressao_sistolica: String,
    pressao_diastolica: String,
    pressao_arterial_media: String,
    frequencia_respiratoria: String,
    saturacao_o2: String,
    temperatura: String,
    glicemia: String,
    momento_coleta: String,
    sinais_vitais_obs: String,
    cid: String,
    diagnostico_atual: String,
    diagnostico_previo: String,
    resultado_exames: String,
    conduta: String,
) -> Result<String, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let id = Uuid::new_v4().to_string();
    let agora = chrono::Local::now();
    let data = agora.format("%Y-%m-%d %H:%M").to_string();
    let criado_em = agora.to_rfc3339();

    conn.execute(
        "INSERT INTO atendimentos (id, paciente_id, data, primeira_consulta, tipo_atendimento, hpp, historia_familiar, alergias, medicacao_uso, exame_fisico, frequencia_cardiaca, pressao_sistolica, pressao_diastolica, pressao_arterial_media, frequencia_respiratoria, saturacao_o2, temperatura, glicemia, momento_coleta, sinais_vitais_obs, cid, diagnostico_atual, diagnostico_previo, resultado_exames, conduta, criado_em)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?17, ?18, ?19, ?20, ?21, ?22, ?23, ?24, ?25, ?26)",
        params![id, paciente_id, data, primeira_consulta, tipo_atendimento, hpp, historia_familiar, alergias, medicacao_uso, exame_fisico, frequencia_cardiaca, pressao_sistolica, pressao_diastolica, pressao_arterial_media, frequencia_respiratoria, saturacao_o2, temperatura, glicemia, momento_coleta, sinais_vitais_obs, cid, diagnostico_atual, diagnostico_previo, resultado_exames, conduta, criado_em],
    )
    .map_err(|e| e.to_string())?;

    Ok(id)
}

#[tauri::command]
fn update_visit(
    state: State<DbState>,
    id: String,
    primeira_consulta: String,
    tipo_atendimento: String,
    hpp: String,
    historia_familiar: String,
    alergias: String,
    medicacao_uso: String,
    exame_fisico: String,
    frequencia_cardiaca: String,
    pressao_sistolica: String,
    pressao_diastolica: String,
    pressao_arterial_media: String,
    frequencia_respiratoria: String,
    saturacao_o2: String,
    temperatura: String,
    glicemia: String,
    momento_coleta: String,
    sinais_vitais_obs: String,
    cid: String,
    diagnostico_atual: String,
    diagnostico_previo: String,
    resultado_exames: String,
    conduta: String,
) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "UPDATE atendimentos SET primeira_consulta=?1, tipo_atendimento=?2, hpp=?3, historia_familiar=?4, alergias=?5, medicacao_uso=?6, exame_fisico=?7, frequencia_cardiaca=?8, pressao_sistolica=?9, pressao_diastolica=?10, pressao_arterial_media=?11, frequencia_respiratoria=?12, saturacao_o2=?13, temperatura=?14, glicemia=?15, momento_coleta=?16, sinais_vitais_obs=?17, cid=?18, diagnostico_atual=?19, diagnostico_previo=?20, resultado_exames=?21, conduta=?22 WHERE id=?23",
        params![primeira_consulta, tipo_atendimento, hpp, historia_familiar, alergias, medicacao_uso, exame_fisico, frequencia_cardiaca, pressao_sistolica, pressao_diastolica, pressao_arterial_media, frequencia_respiratoria, saturacao_o2, temperatura, glicemia, momento_coleta, sinais_vitais_obs, cid, diagnostico_atual, diagnostico_previo, resultado_exames, conduta, id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn list_visits(state: State<DbState>, paciente_id: String) -> Result<Vec<VisitListItem>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare(
            "SELECT id, data, diagnostico_atual, COALESCE(tipo_atendimento, ''), COALESCE(primeira_consulta, ''), COALESCE(queixa_principal, ''), COALESCE(conduta, '') FROM atendimentos
             WHERE paciente_id = ?1 ORDER BY data DESC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![paciente_id], |row| {
            let diagnostico: String = row.get(2)?;
            let resumo = if diagnostico.chars().count() > 80 {
                let corte: String = diagnostico.chars().take(80).collect();
                format!("{}...", corte)
            } else {
                diagnostico
            };
            Ok(VisitListItem {
                id: row.get(0)?,
                data: row.get(1)?,
                resumo,
                tipo_atendimento: row.get(3)?,
                trecho: {
                    let t: String = row.get(4)?;
                    t.split_whitespace().collect::<Vec<_>>().join(" ").chars().take(400).collect()
                },
                queixa: row.get(5)?,
                conduta: {
                    let c: String = row.get(6)?;
                    c.split_whitespace().collect::<Vec<_>>().join(" ").chars().take(240).collect()
                },
            })
        })
        .map_err(|e| e.to_string())?;

    let mut result = Vec::new();
    for r in rows {
        result.push(r.map_err(|e| e.to_string())?);
    }
    Ok(result)
}

#[tauri::command]
fn set_visit_queixa(state: State<DbState>, id: String, queixa: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let limpa: String = queixa.trim().chars().take(200).collect();
    conn.execute(
        "UPDATE atendimentos SET queixa_principal = ?1 WHERE id = ?2",
        params![limpa, id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn get_visit_queixa(state: State<DbState>, id: String) -> Result<String, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.query_row(
        "SELECT COALESCE(queixa_principal, '') FROM atendimentos WHERE id = ?1",
        params![id],
        |row| row.get(0),
    )
    .map_err(|e| e.to_string())
}

#[tauri::command]
fn get_visit(state: State<DbState>, id: String) -> Result<Visit, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.query_row(
        "SELECT id, paciente_id, data, COALESCE(primeira_consulta, ''), COALESCE(tipo_atendimento, ''), hpp, historia_familiar, alergias, medicacao_uso, exame_fisico, COALESCE(frequencia_cardiaca, ''), COALESCE(pressao_sistolica, ''), COALESCE(pressao_diastolica, ''), COALESCE(pressao_arterial_media, ''), COALESCE(frequencia_respiratoria, ''), COALESCE(saturacao_o2, ''), COALESCE(temperatura, ''), COALESCE(glicemia, ''), COALESCE(momento_coleta, ''), COALESCE(sinais_vitais_obs, ''), COALESCE(cid, ''), diagnostico_atual, diagnostico_previo, resultado_exames, conduta, criado_em
         FROM atendimentos WHERE id = ?1",
        params![id],
        |row| {
            Ok(Visit {
                id: row.get(0)?,
                paciente_id: row.get(1)?,
                data: row.get(2)?,
                primeira_consulta: row.get(3)?,
                tipo_atendimento: row.get(4)?,
                hpp: row.get(5)?,
                historia_familiar: row.get(6)?,
                alergias: row.get(7)?,
                medicacao_uso: row.get(8)?,
                exame_fisico: row.get(9)?,
                frequencia_cardiaca: row.get(10)?,
                pressao_sistolica: row.get(11)?,
                pressao_diastolica: row.get(12)?,
                pressao_arterial_media: row.get(13)?,
                frequencia_respiratoria: row.get(14)?,
                saturacao_o2: row.get(15)?,
                temperatura: row.get(16)?,
                glicemia: row.get(17)?,
                momento_coleta: row.get(18)?,
                sinais_vitais_obs: row.get(19)?,
                cid: row.get(20)?,
                diagnostico_atual: row.get(21)?,
                diagnostico_previo: row.get(22)?,
                resultado_exames: row.get(23)?,
                conduta: row.get(24)?,
                criado_em: row.get(25)?,
            })
        },
    )
    .map_err(|e| e.to_string())
}

#[tauri::command]
fn get_resumo(state: State<DbState>) -> Result<Resumo, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let total_pacientes: i64 = conn
        .query_row("SELECT COUNT(*) FROM pacientes", [], |row| row.get(0))
        .map_err(|e| e.to_string())?;

    let uma_semana_atras = (chrono::Local::now() - chrono::Duration::days(7))
        .format("%Y-%m-%d %H:%M")
        .to_string();

    let atendimentos_semana: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM atendimentos WHERE data >= ?1",
            params![uma_semana_atras],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;

    let hoje = chrono::Local::now().format("%Y-%m-%d").to_string();
    let padrao_hoje = format!("{}%", hoje);
    let atendidos_hoje: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM atendimentos WHERE data LIKE ?1",
            params![padrao_hoje],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;
    let urgencias_hoje: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM atendimentos WHERE data LIKE ?1 AND tipo_atendimento = 'Urgência'",
            params![padrao_hoje],
            |row| row.get(0),
        )
        .map_err(|e| e.to_string())?;

    Ok(Resumo {
        total_pacientes,
        atendimentos_semana,
        atendidos_hoje,
        urgencias_hoje,
    })
}

// Data (YYYY-MM-DD) do backup automático mais recente, ou None se não houver nenhum.
#[tauri::command]
fn get_ultimo_backup() -> Option<String> {
    let pasta = caminho_pasta_backups().ok()?;
    let mut datas: Vec<String> = std::fs::read_dir(&pasta)
        .ok()?
        .filter_map(|e| e.ok())
        .filter_map(|e| e.file_name().to_str().map(|n| n.to_string()))
        .filter_map(|n| {
            n.strip_prefix("prontuario-backup-")
                .and_then(|r| r.strip_suffix(".db"))
                .map(|d| d.to_string())
        })
        .collect();
    datas.sort();
    datas.pop()
}

#[tauri::command]
fn get_dados_recorrentes(state: State<DbState>, paciente_id: String) -> Result<Option<DadosRecorrentes>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let resultado = conn
        .query_row(
            "SELECT hpp, historia_familiar, alergias, medicacao_uso, COALESCE(NULLIF(diagnostico_atual, ''), diagnostico_previo) FROM atendimentos
             WHERE paciente_id = ?1
             ORDER BY data DESC LIMIT 1",
            params![paciente_id],
            |row| {
                Ok(DadosRecorrentes {
                    hpp: row.get(0)?,
                    historia_familiar: row.get(1)?,
                    alergias: row.get(2)?,
                    medicacao_uso: row.get(3)?,
                    diagnostico_previo: row.get(4)?,
                })
            },
        )
        .ok();
    Ok(resultado)
}

#[tauri::command]
fn get_atendimentos_recentes(state: State<DbState>) -> Result<Vec<AtendimentoRecente>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare(
            "SELECT a.id, a.paciente_id, p.nome, a.data, COALESCE(a.tipo_atendimento, ''),
                    COALESCE(a.queixa_principal, ''), COALESCE(NULLIF(a.diagnostico_atual, ''), a.diagnostico_previo, ''),
                    COALESCE(a.primeira_consulta, '')
             FROM atendimentos a
             JOIN pacientes p ON p.id = a.paciente_id
             ORDER BY a.data DESC
             LIMIT 2000",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map([], |row| {
            Ok(AtendimentoRecente {
                atendimento_id: row.get(0)?,
                paciente_id: row.get(1)?,
                paciente_nome: row.get(2)?,
                data: row.get(3)?,
                tipo_atendimento: row.get(4)?,
                queixa: row.get(5)?,
                diagnostico: row.get(6)?,
                trecho: {
                    let t: String = row.get(7)?;
                    t.split_whitespace().collect::<Vec<_>>().join(" ").chars().take(200).collect()
                },
            })
        })
        .map_err(|e| e.to_string())?;

    let mut result = Vec::new();
    for r in rows {
        result.push(r.map_err(|e| e.to_string())?);
    }
    Ok(result)
}

#[tauri::command]
fn add_exame_evolucao(
    state: State<DbState>,
    paciente_id: String,
    nome_exame: String,
    data: String,
    resultado: String,
) -> Result<String, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let id = Uuid::new_v4().to_string();
    let criado_em = chrono::Local::now().to_rfc3339();

    conn.execute(
        "INSERT INTO exames_evolucao (id, paciente_id, nome_exame, data, resultado, criado_em)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
        params![id, paciente_id, nome_exame, data, resultado, criado_em],
    )
    .map_err(|e| e.to_string())?;

    Ok(id)
}

#[tauri::command]
fn list_exames_evolucao(state: State<DbState>, paciente_id: String) -> Result<Vec<ExameEvolucao>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare(
            "SELECT id, nome_exame, data, resultado FROM exames_evolucao
             WHERE paciente_id = ?1 ORDER BY data ASC, criado_em ASC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![paciente_id], |row| {
            Ok(ExameEvolucao {
                id: row.get(0)?,
                nome_exame: row.get(1)?,
                data: row.get(2)?,
                resultado: row.get(3)?,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut lista = Vec::new();
    for r in rows {
        lista.push(r.map_err(|e| e.to_string())?);
    }
    Ok(lista)
}

#[tauri::command]
fn list_nomes_exames_usados(state: State<DbState>, paciente_id: String) -> Result<Vec<String>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare(
            "SELECT DISTINCT nome_exame FROM exames_evolucao
             WHERE paciente_id = ?1 ORDER BY nome_exame COLLATE NOCASE ASC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![paciente_id], |row| row.get(0))
        .map_err(|e| e.to_string())?;

    let mut lista = Vec::new();
    for r in rows {
        lista.push(r.map_err(|e| e.to_string())?);
    }
    Ok(lista)
}

#[tauri::command]
fn delete_exame_evolucao(state: State<DbState>, id: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM exames_evolucao WHERE id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn get_medico_config(state: State<DbState>) -> Result<Option<MedicoConfig>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let resultado = conn
        .query_row(
            "SELECT nome, crm, rqe, especialidade, endereco, telefone, celular, cidade, uf FROM medico_config WHERE id = 1",
            [],
            |row| {
                Ok(MedicoConfig {
                    nome: row.get(0)?,
                    crm: row.get(1)?,
                    rqe: row.get(2)?,
                    especialidade: row.get(3)?,
                    endereco: row.get(4)?,
                    telefone: row.get(5)?,
                    celular: row.get(6)?,
                    cidade: row.get(7)?,
                    uf: row.get(8)?,
                })
            },
        )
        .ok();
    Ok(resultado)
}

#[tauri::command]
fn salvar_medico_config(
    state: State<DbState>,
    nome: String,
    crm: String,
    rqe: String,
    especialidade: String,
    endereco: String,
    telefone: String,
    celular: String,
    cidade: String,
    uf: String,
) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT OR REPLACE INTO medico_config (id, nome, crm, rqe, especialidade, endereco, telefone, celular, cidade, uf)
         VALUES (1, ?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
        params![nome, crm, rqe, especialidade, endereco, telefone, celular, cidade, uf],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn add_modelo_documento(
    state: State<DbState>,
    tipo_documento: String,
    nome: String,
    conteudo: String,
) -> Result<String, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let id = Uuid::new_v4().to_string();
    let criado_em = chrono::Local::now().to_rfc3339();

    conn.execute(
        "INSERT INTO modelos_documento (id, tipo_documento, nome, conteudo, criado_em)
         VALUES (?1, ?2, ?3, ?4, ?5)",
        params![id, tipo_documento, nome, conteudo, criado_em],
    )
    .map_err(|e| e.to_string())?;

    Ok(id)
}

#[tauri::command]
fn list_modelos_documento(state: State<DbState>, tipo_documento: String) -> Result<Vec<ModeloDocumento>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare(
            "SELECT id, nome, conteudo FROM modelos_documento
             WHERE tipo_documento = ?1 ORDER BY nome COLLATE NOCASE ASC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![tipo_documento], |row| {
            Ok(ModeloDocumento {
                id: row.get(0)?,
                nome: row.get(1)?,
                conteudo: row.get(2)?,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut lista = Vec::new();
    for r in rows {
        lista.push(r.map_err(|e| e.to_string())?);
    }
    Ok(lista)
}

#[tauri::command]
fn delete_modelo_documento(state: State<DbState>, id: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM modelos_documento WHERE id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn add_documento(
    state: State<DbState>,
    paciente_id: String,
    tipo: String,
    conteudo: String,
) -> Result<String, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let id = Uuid::new_v4().to_string();
    let agora = chrono::Local::now().to_rfc3339();

    conn.execute(
        "INSERT INTO documentos_gerados (id, paciente_id, tipo, conteudo, criado_em, atualizado_em)
         VALUES (?1, ?2, ?3, ?4, ?5, ?5)",
        params![id, paciente_id, tipo, conteudo, agora],
    )
    .map_err(|e| e.to_string())?;

    Ok(id)
}

#[tauri::command]
fn update_documento(
    state: State<DbState>,
    id: String,
    tipo: String,
    conteudo: String,
) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let agora = chrono::Local::now().to_rfc3339();
    conn.execute(
        "UPDATE documentos_gerados SET tipo = ?1, conteudo = ?2, atualizado_em = ?3 WHERE id = ?4",
        params![tipo, conteudo, agora, id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn list_documentos(state: State<DbState>, paciente_id: String) -> Result<Vec<DocumentoGerado>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare(
            "SELECT id, tipo, conteudo, atualizado_em FROM documentos_gerados
             WHERE paciente_id = ?1 ORDER BY atualizado_em DESC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![paciente_id], |row| {
            Ok(DocumentoGerado {
                id: row.get(0)?,
                tipo: row.get(1)?,
                conteudo: row.get(2)?,
                atualizado_em: row.get(3)?,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut lista = Vec::new();
    for r in rows {
        lista.push(r.map_err(|e| e.to_string())?);
    }
    Ok(lista)
}

#[tauri::command]
fn delete_documento(state: State<DbState>, id: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM documentos_gerados WHERE id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn delete_patient(state: State<DbState>, id: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM atendimentos WHERE paciente_id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM documentos_gerados WHERE paciente_id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM exames_evolucao WHERE paciente_id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM pacientes WHERE id = ?1", params![id])
        .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn toggle_favorito(state: State<DbState>, id: String, favorito: bool) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "UPDATE pacientes SET favorito = ?1 WHERE id = ?2",
        params![favorito as i64, id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[derive(Serialize, Deserialize)]
struct InfoVersaoRemota {
    versao: String,
    notas: String,
    #[serde(default)]
    data: String,
    #[serde(default)]
    recompilacao_necessaria: bool,
    url_download: String,
}

#[derive(Serialize)]
struct ResultadoAtualizacao {
    atualizacao_disponivel: bool,
    versao_atual: String,
    versao_nova: Option<String>,
    notas: Option<String>,
    recompilacao_necessaria: Option<bool>,
    url_download: Option<String>,
}

fn versao_para_tupla(v: &str) -> (u32, u32, u32) {
    let partes: Vec<u32> = v.trim().split('.').map(|p| p.trim().parse().unwrap_or(0)).collect();
    (
        *partes.first().unwrap_or(&0),
        *partes.get(1).unwrap_or(&0),
        *partes.get(2).unwrap_or(&0),
    )
}

#[tauri::command]
async fn verificar_atualizacao() -> Result<ResultadoAtualizacao, String> {
    let client = ClientBuilder::new()
        .build()
        .map_err(|e| e.to_string())?;

    let request = HttpRequestBuilder::new("GET", URL_VERSAO_REMOTA)
        .map_err(|e| e.to_string())?
        .response_type(ResponseType::Json);

    let resposta = client.send(request).await.map_err(|_| {
        "Não foi possível conectar à internet para verificar atualizações. Confira sua conexão e tente novamente.".to_string()
    })?;

    let dados = resposta
        .read()
        .await
        .map_err(|e| e.to_string())?;

    let info: InfoVersaoRemota = serde_json::from_value(dados.data)
        .map_err(|_| "Não foi possível entender a resposta do servidor de atualização.".to_string())?;

    let disponivel = versao_para_tupla(&info.versao) > versao_para_tupla(VERSAO_ATUAL);

    if disponivel {
        Ok(ResultadoAtualizacao {
            atualizacao_disponivel: true,
            versao_atual: VERSAO_ATUAL.to_string(),
            versao_nova: Some(info.versao),
            notas: Some(info.notas),
            recompilacao_necessaria: Some(info.recompilacao_necessaria),
            url_download: Some(info.url_download),
        })
    } else {
        Ok(ResultadoAtualizacao {
            atualizacao_disponivel: false,
            versao_atual: VERSAO_ATUAL.to_string(),
            versao_nova: None,
            notas: None,
            recompilacao_necessaria: None,
            url_download: None,
        })
    }
}

const MAXIMO_BACKUPS_AUTOMATICOS: usize = 30;

fn caminho_pasta_backups() -> Result<std::path::PathBuf, String> {
    let documentos =
        tauri::api::path::document_dir().ok_or("não foi possível localizar a pasta Documentos")?;
    let pasta = documentos.join("Prontuario-Backups");
    std::fs::create_dir_all(&pasta).map_err(|e| e.to_string())?;
    Ok(pasta)
}

// Backup silencioso (sem diálogo), feito automaticamente ao abrir e ao fechar o app.
// Salva em Documentos\Prontuario-Backups\, um arquivo por dia (dispara de novo no mesmo
// dia apenas substitui o arquivo daquele dia), e mantém só os mais recentes.
fn backup_automatico_silencioso(app_handle: &tauri::AppHandle) {
    let resultado = (|| -> Result<(), String> {
        let app_dir = app_handle
            .path_resolver()
            .app_data_dir()
            .ok_or("não foi possível localizar a pasta de dados")?;
        let origem = app_dir.join("prontuario.db");
        if !origem.exists() {
            return Ok(());
        }

        let pasta_backups = caminho_pasta_backups()?;
        let hoje = chrono::Local::now().format("%Y-%m-%d").to_string();
        let destino = pasta_backups.join(format!("prontuario-backup-{}.db", hoje));
        std::fs::copy(&origem, &destino).map_err(|e| e.to_string())?;

        let mut arquivos: Vec<std::path::PathBuf> = std::fs::read_dir(&pasta_backups)
            .map_err(|e| e.to_string())?
            .filter_map(|entrada| entrada.ok())
            .map(|entrada| entrada.path())
            .filter(|p| {
                p.extension().map(|e| e == "db").unwrap_or(false)
                    && p
                        .file_name()
                        .and_then(|n| n.to_str())
                        .map(|n| n.starts_with("prontuario-backup-"))
                        .unwrap_or(false)
            })
            .collect();
        arquivos.sort();

        if arquivos.len() > MAXIMO_BACKUPS_AUTOMATICOS {
            let excedentes = arquivos.len() - MAXIMO_BACKUPS_AUTOMATICOS;
            for arquivo in &arquivos[0..excedentes] {
                let _ = std::fs::remove_file(arquivo);
            }
        }

        Ok(())
    })();

    if let Err(erro) = resultado {
        eprintln!("Falha no backup automático: {}", erro);
    }
}

#[tauri::command]
async fn fazer_backup(app_handle: tauri::AppHandle) -> Result<bool, String> {
    let app_dir = app_handle
        .path_resolver()
        .app_data_dir()
        .ok_or("não foi possível localizar a pasta de dados")?;
    let origem = app_dir.join("prontuario.db");

    let destino = tauri::api::dialog::blocking::FileDialogBuilder::new()
        .set_file_name("prontuario-backup.db")
        .save_file();

    match destino {
        Some(caminho) => {
            std::fs::copy(&origem, &caminho).map_err(|e| e.to_string())?;
            Ok(true)
        }
        None => Ok(false),
    }
}

#[tauri::command]
fn restaurar_backup(app_handle: tauri::AppHandle, state: State<DbState>) -> Result<bool, String> {
    let origem = tauri::api::dialog::blocking::FileDialogBuilder::new()
        .add_filter("Banco de dados (.db)", &["db"])
        .pick_file();

    let origem = match origem {
        Some(caminho) => caminho,
        None => return Ok(false),
    };

    let app_dir = app_handle
        .path_resolver()
        .app_data_dir()
        .ok_or("não foi possível localizar a pasta de dados")?;
    let destino = app_dir.join("prontuario.db");

    let mut conn_guard = state.0.lock().map_err(|e| e.to_string())?;

    // Guarda uma cópia de segurança do banco atual antes de sobrescrever, caso a
    // restauração tenha sido um engano. Fica fora da rotação dos backups automáticos
    // (prefixo diferente), então nunca é apagada sozinha.
    if destino.exists() {
        if let Ok(pasta_backups) = caminho_pasta_backups() {
            let agora = chrono::Local::now().format("%Y-%m-%d_%H-%M-%S").to_string();
            let seguranca = pasta_backups.join(format!("antes-de-restaurar-{}.db", agora));
            let _ = std::fs::copy(&destino, &seguranca);
        }
    }

    // Fecha a conexão atual para liberar o arquivo antes de substituí-lo
    let conexao_antiga = std::mem::replace(
        &mut *conn_guard,
        Connection::open_in_memory().map_err(|e| e.to_string())?,
    );
    drop(conexao_antiga);

    std::fs::copy(&origem, &destino).map_err(|e| e.to_string())?;

    let nova_conexao = Connection::open(&destino).map_err(|e| e.to_string())?;
    init_db(&nova_conexao);
    *conn_guard = nova_conexao;

    Ok(true)
}

#[tauri::command]
fn list_visits_completos(state: State<DbState>, paciente_id: String) -> Result<Vec<Visit>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let mut stmt = conn
        .prepare(
            "SELECT id, paciente_id, data, COALESCE(primeira_consulta, ''), COALESCE(tipo_atendimento, ''), hpp, historia_familiar, alergias, medicacao_uso, exame_fisico, COALESCE(frequencia_cardiaca, ''), COALESCE(pressao_sistolica, ''), COALESCE(pressao_diastolica, ''), COALESCE(pressao_arterial_media, ''), COALESCE(frequencia_respiratoria, ''), COALESCE(saturacao_o2, ''), COALESCE(temperatura, ''), COALESCE(glicemia, ''), COALESCE(momento_coleta, ''), COALESCE(sinais_vitais_obs, ''), COALESCE(cid, ''), diagnostico_atual, diagnostico_previo, resultado_exames, conduta, criado_em
             FROM atendimentos WHERE paciente_id = ?1 ORDER BY data ASC",
        )
        .map_err(|e| e.to_string())?;

    let rows = stmt
        .query_map(params![paciente_id], |row| {
            Ok(Visit {
                id: row.get(0)?,
                paciente_id: row.get(1)?,
                data: row.get(2)?,
                primeira_consulta: row.get(3)?,
                tipo_atendimento: row.get(4)?,
                hpp: row.get(5)?,
                historia_familiar: row.get(6)?,
                alergias: row.get(7)?,
                medicacao_uso: row.get(8)?,
                exame_fisico: row.get(9)?,
                frequencia_cardiaca: row.get(10)?,
                pressao_sistolica: row.get(11)?,
                pressao_diastolica: row.get(12)?,
                pressao_arterial_media: row.get(13)?,
                frequencia_respiratoria: row.get(14)?,
                saturacao_o2: row.get(15)?,
                temperatura: row.get(16)?,
                glicemia: row.get(17)?,
                momento_coleta: row.get(18)?,
                sinais_vitais_obs: row.get(19)?,
                cid: row.get(20)?,
                diagnostico_atual: row.get(21)?,
                diagnostico_previo: row.get(22)?,
                resultado_exames: row.get(23)?,
                conduta: row.get(24)?,
                criado_em: row.get(25)?,
            })
        })
        .map_err(|e| e.to_string())?;

    let mut result = Vec::new();
    for r in rows {
        result.push(r.map_err(|e| e.to_string())?);
    }
    Ok(result)
}

// ---------- main ----------

fn main() {
    tauri::Builder::default()
        .setup(|app| {
            let app_dir = app
                .path_resolver()
                .app_data_dir()
                .expect("não foi possível obter a pasta de dados do app");
            std::fs::create_dir_all(&app_dir).expect("não foi possível criar a pasta de dados");

            let db_path = app_dir.join("prontuario.db");
            let conn = Connection::open(db_path).expect("erro ao abrir o banco de dados");
            init_db(&conn);

            app.manage(DbState(Mutex::new(conn)));

            // Backup automático ao abrir o app (roda em segundo plano, não atrasa a janela)
            let handle_backup_abertura = app.handle();
            std::thread::spawn(move || {
                backup_automatico_silencioso(&handle_backup_abertura);
            });

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            add_patient,
            update_patient,
            list_patients,
            get_patient,
            add_visit,
            update_visit,
            list_visits,
            get_visit,
            get_resumo,
            get_dados_recorrentes,
            get_atendimentos_recentes,
            delete_patient,
            toggle_favorito,
            fazer_backup,
            get_ultimo_backup,
            list_visits_completos,
            add_exame_evolucao,
            list_exames_evolucao,
            list_nomes_exames_usados,
            delete_exame_evolucao,
            get_medico_config,
            salvar_medico_config,
            add_modelo_documento,
            list_modelos_documento,
            delete_modelo_documento,
            add_documento,
            update_documento,
            list_documentos,
            delete_documento,
            auth_configurada,
            configurar_auth,
            verificar_senha,
            obter_pergunta_seguranca,
            verificar_resposta_seguranca,
            redefinir_senha,
            alterar_senha,
            list_documentos_periodo,
            list_atendimentos_periodo,
            list_pacientes_relatorio,
            verificar_atualizacao,
            restaurar_backup,
            set_patient_tags,
            list_all_tags,
            set_observacao_fixa,
            set_patient_whatsapp,
            set_visit_queixa,
            get_visit_queixa
        ])
        .build(tauri::generate_context!())
        .expect("erro ao rodar a aplicação")
        .run(|app_handle, evento| {
            if let tauri::RunEvent::ExitRequested { .. } = evento {
                backup_automatico_silencioso(app_handle);
            }
        });
}
