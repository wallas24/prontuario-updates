const { invoke } = window.__TAURI__.tauri;

// ---------- Estado simples ----------
let pacienteAtualId = null;
let origemCadastro = "lista"; // de onde o cadastro foi aberto (para o Voltar/Cancelar)
let atendimentoDataAtual = null; // texto da data exibida no atendimento aberto (para impressão)

// ---------- Elementos ----------
const telas = {
  inicio: document.getElementById("tela-inicio"),
  recentes: document.getElementById("tela-recentes"),
  lista: document.getElementById("tela-lista"),
  cadastro: document.getElementById("tela-cadastro"),
  ficha: document.getElementById("tela-ficha"),
  atendimento: document.getElementById("tela-atendimento"),
  medicoConfig: document.getElementById("tela-medico-config"),
  relatorios: document.getElementById("tela-relatorios"),
};

const btnVoltar = document.getElementById("btn-voltar");
const campoBusca = document.getElementById("campo-busca");

function travarMenuLateral(bloquear) {
  document.querySelectorAll(".sidebar-item").forEach((b) => {
    b.disabled = bloquear;
  });
  const aviso = document.getElementById("sidebar-bloqueado-aviso");
  if (aviso) aviso.classList.toggle("mostrar", bloquear);
}

function mostrarTela(nome) {
  Object.values(telas).forEach((t) => t.classList.add("oculto"));
  telas[nome].classList.remove("oculto");
  travarMenuLateral(nome === "atendimento");

  if (nome === "inicio") {
    btnVoltar.classList.add("oculto");
  } else {
    btnVoltar.classList.remove("oculto");
  }

  document.querySelectorAll(".sidebar-nav .sidebar-item").forEach((b) => b.classList.remove("ativo"));
  document.getElementById("nav-medico-config").classList.remove("ativo");
  if (nome === "inicio") document.getElementById("nav-home").classList.add("ativo");
  if (nome === "recentes") document.getElementById("nav-inicio").classList.add("ativo");
  if (nome === "lista") document.getElementById("nav-pacientes").classList.add("ativo");
  if (nome === "relatorios") document.getElementById("nav-relatorios").classList.add("ativo");
  if (nome === "medicoConfig") {
    document.getElementById("nav-medico-config").classList.add("ativo");
    document.getElementById("config-submenu").classList.add("aberto");
    document.getElementById("config-seta").classList.add("aberta");
  }
}

// ---------- Utilidades ----------

function escapeHtml(texto) {
  const div = document.createElement("div");
  div.textContent = texto || "";
  return div.innerHTML;
}

function formatarDataHoraAtendimento(dataStr) {
  // aceita "YYYY-MM-DD HH:MM" e devolve "DD-MM-YYYY HH:MM"
  if (!dataStr) return dataStr;
  const [parteData, parteHora] = dataStr.split(" ");
  const [ano, mes, dia] = (parteData || "").split("-");
  if (!ano || !mes || !dia) return dataStr;
  return parteHora ? `${dia}-${mes}-${ano} ${parteHora}` : `${dia}-${mes}-${ano}`;
}

function formatarDataHoraIso(iso) {
  // aceita datas no formato ISO (ex.: 2026-09-28T09:16:06-03:00) e devolve "28/09/2026 09:16"
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "");
}

function formatarData(dataStr) {
  // aceita "YYYY-MM-DD HH:MM" ou "YYYY-MM-DD"
  const parte = dataStr.split(" ")[0];
  const [ano, mes, dia] = parte.split("-");
  if (!ano || !mes || !dia) return dataStr;
  return `${dia}/${mes}/${ano}`;
}

function formatarDataHora(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d)) return "—";
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function calcularIdade(dataNascimento) {
  if (!dataNascimento) return null;
  const nasc = new Date(dataNascimento + "T00:00:00");
  if (isNaN(nasc)) return null;
  const hoje = new Date();
  let idade = hoje.getFullYear() - nasc.getFullYear();
  const m = hoje.getMonth() - nasc.getMonth();
  if (m < 0 || (m === 0 && hoje.getDate() < nasc.getDate())) idade--;
  return idade >= 0 ? idade : null;
}

function iniciais(nome) {
  const partes = (nome || "").trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return "?";
  if (partes.length === 1) return partes[0].slice(0, 2).toUpperCase();
  return (partes[0][0] + partes[partes.length - 1][0]).toUpperCase();
}

function corAvatar(nome) {
  const cores = ["#2D6A9F", "#B9793B", "#5B6B8C", "#7A5C99", "#3E8F6B", "#A15C5C"];
  let hash = 0;
  for (let i = 0; i < (nome || "").length; i++) {
    hash = nome.charCodeAt(i) + ((hash << 5) - hash);
  }
  return cores[Math.abs(hash) % cores.length];
}

function hojeLocalStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function diasDesde(dataStr) {
  if (!dataStr) return Infinity;
  const parte = dataStr.split(" ")[0];
  const d = new Date(parte + "T00:00:00");
  if (isNaN(d)) return Infinity;
  return Math.floor((new Date().setHours(0, 0, 0, 0) - d.getTime()) / 86400000);
}

function cpfValido(valor) {
  const d = (valor || "").replace(/\D/g, "");
  if (d.length !== 11 || /^(\d)\1{10}$/.test(d)) return true; // não é CPF (ex: RG) — não valida
  const calcDigito = (base) => {
    let soma = 0;
    let peso = base.length + 1;
    for (const c of base) soma += Number(c) * peso--;
    const resto = soma % 11;
    return resto < 2 ? 0 : 11 - resto;
  };
  const d1 = calcDigito(d.slice(0, 9));
  const d2 = calcDigito(d.slice(0, 10));
  return d1 === Number(d[9]) && d2 === Number(d[10]);
}

// ---------- Breadcrumb ----------

function setBreadcrumb(itens) {
  const el = document.getElementById("breadcrumb");
  if (!itens || itens.length === 0) {
    el.innerHTML = "";
    return;
  }
  el.innerHTML = itens
    .map((it, i) => {
      const isLast = i === itens.length - 1;
      const texto = escapeHtml(it.text);
      if (isLast || !it.onClick) {
        return `<span class="crumb-atual">${texto}</span>`;
      }
      return `<span class="crumb-link" data-idx="${i}">${texto}</span><span class="crumb-separador">/</span>`;
    })
    .join("");
  itens.forEach((it, i) => {
    if (it.onClick && i !== itens.length - 1) {
      const link = el.querySelector(`[data-idx="${i}"]`);
      if (link) link.addEventListener("click", it.onClick);
    }
  });
}

function irParaListaPacientes() {
  document.getElementById("nav-pacientes").click();
}

// ---------- Confirmação (modal próprio, substitui o confirm() nativo) ----------

function confirmarAcao(mensagem) {
  return new Promise((resolve) => {
    const overlay = document.getElementById("modal-confirmar");
    document.getElementById("modal-confirmar-mensagem").textContent = mensagem;
    overlay.classList.remove("oculto");

    const btnOk = document.getElementById("modal-confirmar-ok");
    const btnCancelar = document.getElementById("modal-confirmar-cancelar");

    function limpar(resultado) {
      overlay.classList.add("oculto");
      btnOk.removeEventListener("click", onOk);
      btnCancelar.removeEventListener("click", onCancelar);
      resolve(resultado);
    }
    function onOk() { limpar(true); }
    function onCancelar() { limpar(false); }

    btnOk.addEventListener("click", onOk);
    btnCancelar.addEventListener("click", onCancelar);
  });
}

// ---------- Toast de notificação ----------

let toastTimeout;
function mostrarToast(mensagem) {
  const toast = document.getElementById("toast");
  toast.textContent = mensagem;
  toast.classList.remove("oculto");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.add("oculto"), 3000);
}

// ---------- Tema claro/escuro ----------

const btnTema = document.getElementById("btn-tema");

function aplicarTema(tema) {
  document.documentElement.setAttribute("data-theme", tema);
  btnTema.innerHTML =
    tema === "dark"
      ? '<span class="sidebar-item-icone"><svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><circle cx="10" cy="10" r="3.2"/><line x1="10" y1="2.5" x2="10" y2="4.5"/><line x1="10" y1="15.5" x2="10" y2="17.5"/><line x1="2.5" y1="10" x2="4.5" y2="10"/><line x1="15.5" y1="10" x2="17.5" y2="10"/><line x1="4.9" y1="4.9" x2="6.3" y2="6.3"/><line x1="13.7" y1="13.7" x2="15.1" y2="15.1"/><line x1="4.9" y1="15.1" x2="6.3" y2="13.7"/><line x1="13.7" y1="6.3" x2="15.1" y2="4.9"/></svg></span> Tema claro'
      : '<span class="sidebar-item-icone"><svg viewBox="0 0 20 20" fill="currentColor"><path d="M15.5 12.5a6 6 0 1 1-8-8 5 5 0 0 0 8 8Z"/></svg></span> Tema escuro';
  localStorage.setItem("prontuario-tema", tema);
}

aplicarTema(localStorage.getItem("prontuario-tema") || "light");

btnTema.addEventListener("click", () => {
  const atual = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
  aplicarTema(atual);
});

// ---------- Máscaras: telefone e CPF ----------

function mascararTelefone(valor) {
  const d = valor.replace(/\D/g, "").slice(0, 11);
  if (d.length === 0) return "";
  if (d.length <= 2) return `(${d}`;
  if (d.length <= 6) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
  if (d.length <= 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
}

function mascararDocumento(valor) {
  const d = valor.replace(/\D/g, "").slice(0, 11);
  if (d.length <= 3) return d;
  if (d.length <= 6) return `${d.slice(0, 3)}.${d.slice(3)}`;
  if (d.length <= 9) return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6)}`;
  return `${d.slice(0, 3)}.${d.slice(3, 6)}.${d.slice(6, 9)}-${d.slice(9)}`;
}

document.getElementById("p-telefone").addEventListener("input", (e) => {
  e.target.value = mascararTelefone(e.target.value);
});
document.getElementById("p-telefone2").addEventListener("input", (e) => {
  e.target.value = mascararTelefone(e.target.value);
});
document.getElementById("p-documento").addEventListener("input", (e) => {
  e.target.value = mascararDocumento(e.target.value);
  const aviso = document.getElementById("aviso-cpf");
  const digitos = e.target.value.replace(/\D/g, "");
  if (digitos.length === 11 && !cpfValido(e.target.value)) {
    aviso.classList.remove("oculto");
  } else {
    aviso.classList.add("oculto");
  }
});
document.getElementById("p-nome").addEventListener("input", (e) => {
  document.getElementById("erro-nome").classList.add("oculto");
  document.getElementById("p-nome").classList.remove("campo-invalido");
  const inicio = e.target.selectionStart;
  const fim = e.target.selectionEnd;
  e.target.value = e.target.value.toUpperCase();
  e.target.setSelectionRange(inicio, fim);
});

// ---------- Resumo no topo da lista ----------

async function carregarResumo() {
  const r = await invoke("get_resumo");
  const p = r.total_pacientes === 1 ? "paciente cadastrado" : "pacientes cadastrados";
  const a = r.atendimentos_semana === 1 ? "atendimento" : "atendimentos";
  document.getElementById("inicio-desc-pacientes").textContent = `${r.total_pacientes} ${p}`;
  document.getElementById("inicio-desc-atendimentos").textContent = `${r.atendimentos_semana} ${a} nos últimos 7 dias`;
}

// ---------- Caixas de texto que crescem sozinhas ----------

function autoAjustarAltura(textarea) {
  textarea.style.height = "auto";
  textarea.style.height = textarea.scrollHeight + "px";
}

function ativarAutoAjuste(seletor) {
  document.querySelectorAll(seletor).forEach((ta) => {
    ta.addEventListener("input", () => autoAjustarAltura(ta));
  });
}

function reajustarTodasAsCaixas(seletor) {
  document.querySelectorAll(seletor).forEach((ta) => autoAjustarAltura(ta));
}

ativarAutoAjuste("#form-atendimento textarea, #form-paciente textarea, #modal-documento textarea");

// ---------- Evolução de exames ----------

function formatarDataExame(dataIso) {
  const partes = (dataIso || "").split("-");
  if (partes.length !== 3) return dataIso;
  const [ano, mes, dia] = partes;
  return `${dia}/${mes}/${ano}`;
}

async function carregarExamesEvolucao(pacienteId) {
  const exames = await invoke("list_exames_evolucao", { pacienteId });
  renderizarTabelaExames(exames, pacienteId);

  const nomes = await invoke("list_nomes_exames_usados", { pacienteId });
  document.getElementById("lista-nomes-exames").innerHTML = nomes
    .map((n) => `<option value="${escapeHtml(n)}"></option>`)
    .join("");
}

function renderizarTabelaExames(exames, pacienteId) {
  const wrap = document.getElementById("tabela-exames-wrap");

  if (!exames.length) {
    wrap.innerHTML = '<p class="exames-vazio">Nenhum exame registrado ainda.</p>';
    return;
  }

  const datasUnicas = [...new Set(exames.map((e) => e.data))];
  const nomesUnicos = [...new Set(exames.map((e) => e.nome_exame))].sort((a, b) =>
    a.localeCompare(b, "pt-BR", { sensitivity: "base" })
  );

  const mapa = {};
  exames.forEach((e) => {
    mapa[e.nome_exame + "||" + e.data] = e;
  });

  let html = '<div class="tabela-exames-wrap-scroll"><table class="tabela-exames"><thead><tr><th>Exame</th>';
  datasUnicas.forEach((d) => {
    html += `<th>${formatarDataExame(d)}</th>`;
  });
  html += "</tr></thead><tbody>";

  nomesUnicos.forEach((nome) => {
    html += `<tr><th>${escapeHtml(nome)}</th>`;
    datasUnicas.forEach((d) => {
      const item = mapa[nome + "||" + d];
      html += item
        ? `<td class="celula-exame">${escapeHtml(item.resultado)}<button type="button" class="btn-remover-exame" data-id="${item.id}" title="Remover">✕</button></td>`
        : "<td></td>";
    });
    html += "</tr>";
  });

  html += "</tbody></table></div>";
  wrap.innerHTML = html;

  wrap.querySelectorAll(".btn-remover-exame").forEach((btn) => {
    btn.onclick = async () => {
      const confirmar = await confirmarAcao("Remover este resultado de exame?");
      if (!confirmar) return;
      await invoke("delete_exame_evolucao", { id: btn.dataset.id });
      await carregarExamesEvolucao(pacienteId);
    };
  });
}

document.getElementById("btn-add-exame").onclick = async () => {
  const campoNome = document.getElementById("ex-nome");
  const campoData = document.getElementById("ex-data");
  const campoResultado = document.getElementById("ex-resultado");

  const nome = campoNome.value.trim();
  const data = campoData.value;
  const resultado = campoResultado.value.trim();

  if (!nome || !data || !resultado) {
    mostrarToast("Preencha o exame, a data e o resultado");
    return;
  }

  await invoke("add_exame_evolucao", {
    pacienteId: pacienteAtualId,
    nomeExame: nome,
    data,
    resultado,
  });

  campoNome.value = "";
  campoResultado.value = "";
  campoNome.focus();

  await carregarExamesEvolucao(pacienteAtualId);
  mostrarToast("Exame adicionado");
};

// ---------- Saudação (tela inicial) ----------

function saudacaoPorHorario() {
  const h = new Date().getHours();
  if (h < 12) return "Bom dia";
  if (h < 18) return "Boa tarde";
  return "Boa noite";
}

async function nomeSaudacaoPadrao() {
  const config = await invoke("get_medico_config");
  const primeiroNome = config && config.nome ? config.nome.trim().split(/\s+/)[0] : "";
  return primeiroNome;
}

async function carregarSaudacao() {
  const manual = localStorage.getItem("prontuario-nome-medico");
  const nome = manual || (await nomeSaudacaoPadrao());
  document.getElementById("saudacao-texto").textContent = nome
    ? `${saudacaoPorHorario()}, ${nome}`
    : `${saudacaoPorHorario()}!`;
}

document.getElementById("btn-editar-nome-medico").addEventListener("click", async () => {
  const manual = localStorage.getItem("prontuario-nome-medico");
  document.getElementById("input-nome-medico").value = manual || (await nomeSaudacaoPadrao());
  document.getElementById("modal-nome-medico").classList.remove("oculto");
});
document.getElementById("modal-nome-medico-cancelar").addEventListener("click", () => {
  document.getElementById("modal-nome-medico").classList.add("oculto");
});
document.getElementById("modal-nome-medico-salvar").addEventListener("click", async () => {
  const valor = document.getElementById("input-nome-medico").value.trim();
  const padrao = await nomeSaudacaoPadrao();
  // Se o valor digitado for igual ao padrão (nome cadastrado em Dados do médico), não precisa
  // guardar nada manualmente — a saudação já acompanha o cadastro automaticamente.
  if (valor && valor !== padrao) {
    localStorage.setItem("prontuario-nome-medico", valor);
  } else {
    localStorage.removeItem("prontuario-nome-medico");
  }
  document.getElementById("modal-nome-medico").classList.add("oculto");
  carregarSaudacao();
});

// ---------- Backup manual ----------

document.getElementById("btn-backup").addEventListener("click", async () => {
  try {
    const feito = await invoke("fazer_backup");
    if (feito) {
      mostrarToast("Backup salvo com sucesso");
    }
  } catch (erro) {
    mostrarToast("Não foi possível fazer o backup");
  }
});

document.getElementById("btn-restaurar-backup").addEventListener("click", async () => {
  const confirmado = await confirmarAcao(
    "Isso vai substituir TODOS os dados atuais do sistema pelos dados do arquivo de backup escolhido. Essa ação não pode ser desfeita (além de uma cópia de segurança automática do estado atual, guardada por precaução). Deseja continuar?"
  );
  if (!confirmado) return;

  try {
    const feito = await invoke("restaurar_backup");
    if (feito) {
      mostrarToast("Backup restaurado com sucesso — recarregando…");
      setTimeout(() => window.location.reload(), 1200);
    }
  } catch (erro) {
    mostrarToast(typeof erro === "string" ? erro : "Não foi possível restaurar o backup");
  }
});

// ---------- Verificação de atualização ----------

document.getElementById("btn-verificar-atualizacao").addEventListener("click", async () => {
  const botao = document.getElementById("btn-verificar-atualizacao");
  const textoOriginal = botao.innerHTML;
  botao.disabled = true;
  botao.innerHTML = botao.innerHTML.replace("Verificar atualização", "Verificando…");

  try {
    const resultado = await invoke("verificar_atualizacao");
    if (resultado.atualizacao_disponivel) {
      document.getElementById("atualizacao-versao-atual").textContent = "v" + resultado.versao_atual;
      document.getElementById("atualizacao-versao-nova").textContent = "v" + resultado.versao_nova;
      document.getElementById("atualizacao-notas").textContent = resultado.notas || "";
      document.getElementById("atualizacao-link").value = resultado.url_download || "";
      document.getElementById("modal-atualizacao").classList.remove("oculto");
    } else {
      mostrarToast("Você já está com a versão mais recente");
    }
  } catch (erro) {
    mostrarToast(typeof erro === "string" ? erro : "Não foi possível verificar atualizações agora");
  } finally {
    botao.disabled = false;
    botao.innerHTML = textoOriginal;
  }
});

document.getElementById("modal-atualizacao-fechar").addEventListener("click", () => {
  document.getElementById("modal-atualizacao").classList.add("oculto");
});

document.getElementById("atualizacao-copiar-link").addEventListener("click", async () => {
  const input = document.getElementById("atualizacao-link");
  input.select();
  try {
    await navigator.clipboard.writeText(input.value);
    mostrarToast("Link copiado");
  } catch (erro) {
    mostrarToast("Não foi possível copiar o link — selecione e copie manualmente");
  }
});

// ---------- Esqueleto de carregamento ----------

function renderizarSkeleton(container, quantidade = 3) {
  container.innerHTML = Array.from({ length: quantidade })
    .map(
      () => `
      <div class="skeleton-item">
        <div class="skeleton-bloco" style="width:38px;height:38px;border-radius:50%;"></div>
        <div style="flex:1; display:flex; flex-direction:column; gap:6px;">
          <div class="skeleton-bloco" style="width:55%; height:11px;"></div>
          <div class="skeleton-bloco" style="width:32%; height:9px;"></div>
        </div>
      </div>
    `
    )
    .join("");
}

// ---------- TELA: Atendimentos recentes (início) ----------

async function carregarInicio() {
  setBreadcrumb([]);
  carregarSaudacao();
  carregarResumo();
}

async function carregarRecentes() {
  setBreadcrumb([{ text: "Atendimentos recentes" }]);
  const container = document.getElementById("lista-recentes");
  const vazio = document.getElementById("recentes-vazio");
  vazio.classList.add("oculto");
  renderizarSkeleton(container);

  const recentes = await invoke("get_atendimentos_recentes");

  const el = document.getElementById("resumo-topo-recentes");
  el.textContent = recentes.length === 0 ? "" : `Mostrando os ${recentes.length} atendimentos mais recentes`;

  container.innerHTML = "";

  if (recentes.length === 0) {
    vazio.classList.remove("oculto");
    return;
  }
  vazio.classList.add("oculto");

  const hoje = hojeLocalStr();
  for (const r of recentes) {
    const div = document.createElement("div");
    div.className = "item-atendimento";
    div.innerHTML = `
      <div class="data">${formatarDataHoraAtendimento(r.data)} ${r.data.startsWith(hoje) ? '<span class="badge-hoje">Hoje</span>' : ""} ${tagTipoAtendimento(r.tipo_atendimento)}</div>
      <div class="resumo">${escapeHtml(r.paciente_nome)}</div>
    `;
    div.addEventListener("click", () => abrirAtendimento(r.atendimento_id));
    container.appendChild(div);
  }
}

// ---------- TELA: Lista de pacientes ----------

let ordenacaoPacientesAtual = "ultima";
let filtroTagAtual = "";
let abaListaAtual = "todos";

function listaDeTags(texto) {
  return (texto || "").split("|").map((t) => t.trim()).filter(Boolean);
}

function htmlChipsTags(texto) {
  return listaDeTags(texto).map((t) => `<span class="tag-chip">${escapeHtml(t)}</span>`).join("");
}

function textoPacientes(n) {
  return `${n} ${n === 1 ? "paciente" : "pacientes"}`;
}

function renderizarCondicoes(pacientes) {
  const box = document.getElementById("filtro-tags");
  const contagem = new Map();
  for (const p of pacientes) {
    for (const t of listaDeTags(p.tags)) {
      const k = t.toLowerCase();
      const atual = contagem.get(k) || { nome: t, total: 0 };
      atual.total += 1;
      contagem.set(k, atual);
    }
  }
  const tags = [...contagem.values()].sort((a, b) => b.total - a.total || a.nome.localeCompare(b.nome, "pt-BR"));
  if (filtroTagAtual && !contagem.has(filtroTagAtual.toLowerCase())) filtroTagAtual = "";

  const item = (nome, valor, total) =>
    `<button type="button" class="cond-item ${valor.toLowerCase() === filtroTagAtual.toLowerCase() ? "ativo" : ""}" data-tag="${escapeHtml(valor)}"><span>${escapeHtml(nome)}</span><span class="cond-qtd">${total}</span></button>`;
  box.innerHTML =
    item("Todas", "", pacientes.length) +
    tags.map((t) => item(t.nome, t.nome, t.total)).join("") +
    (tags.length ? "" : '<p class="favoritos-dica">Crie etiquetas no cadastro do paciente (ex.: Hipertenso) para filtrar por aqui.</p>');
  box.querySelectorAll(".cond-item").forEach((b) => {
    b.addEventListener("click", () => {
      filtroTagAtual = b.dataset.tag;
      carregarPacientes();
    });
  });
}

function renderizarFavoritos(pacientes) {
  const box = document.getElementById("favoritos-lista");
  const favs = pacientes
    .filter((p) => p.favorito)
    .sort((a, b) => (b.ultima_consulta || "").localeCompare(a.ultima_consulta || ""));
  box.innerHTML = "";
  for (const p of favs) {
    const el = document.createElement("button");
    el.type = "button";
    el.className = "favorito-item";
    el.innerHTML = `
      <div class="avatar-paciente" style="background-color:${corAvatar(p.nome)}">${iniciais(p.nome)}</div>
      <div class="favorito-texto">
        <strong>${escapeHtml(p.nome)}</strong>
        <span>${p.ultima_consulta ? `última consulta ${textoHaDias(p.ultima_consulta)}` : "sem atendimentos"}</span>
      </div>`;
    el.addEventListener("click", () => abrirFicha(p.id));
    box.appendChild(el);
  }
}

function criarLinhaPaciente(p, hojeStr) {
  const idade = calcularIdade(p.data_nascimento);
  const atendidoHoje = p.ultima_consulta && p.ultima_consulta.startsWith(hojeStr);
  let direita = "";
  if (p.ultima_consulta) {
    if (atendidoHoje) {
      direita = (p.ultima_consulta.split(" ")[1] || "").slice(0, 5);
    } else {
      const [ano, mes, dia] = p.ultima_consulta.split(" ")[0].split("-");
      direita = `${dia}/${mes} · ${textoHaDias(p.ultima_consulta)}`;
    }
  }
  const div = document.createElement("div");
  div.className = "paciente-linha";
  div.tabIndex = 0;
  div.innerHTML = `
    <div class="avatar-paciente avatar-grande" style="background-color:${corAvatar(p.nome)}">${iniciais(p.nome)}</div>
    <div class="paciente-linha-info">
      <div class="paciente-linha-nome">
        <span class="paciente-nome">${escapeHtml(p.nome)}</span>
        ${idade !== null ? `<span class="paciente-idade">${idade} anos</span>` : ""}
        ${p.tem_obs ? '<span class="pill-obs" title="Tem observação fixa">obs.</span>' : ""}
      </div>
      <div class="paciente-linha-meta">
        <span>${escapeHtml(p.telefone || "Sem telefone")}</span>
        ${p.tags ? `<span class="tags-lista-inline">${htmlChipsTags(p.tags)}</span>` : ""}
      </div>
    </div>
    <div class="paciente-linha-direita">
      ${direita ? `<span class="paciente-ultima">${escapeHtml(direita)}</span>` : ""}
      <button type="button" class="btn-mais-atendimento" title="Novo atendimento para este paciente" aria-label="Novo atendimento">+</button>
    </div>`;
  div.addEventListener("click", () => abrirFicha(p.id));
  div.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target === div) abrirFicha(p.id);
  });
  div.querySelector(".btn-mais-atendimento").addEventListener("click", async (e) => {
    e.stopPropagation();
    pacienteAtualId = p.id;
    await abrirNovoAtendimento(p.id);
  });
  return div;
}

function cabecalhoGrupo(titulo, detalhe) {
  const el = document.createElement("div");
  el.className = "grupo-cabecalho";
  el.innerHTML = `<strong>${escapeHtml(titulo)}</strong><span>${escapeHtml(detalhe)}</span>`;
  return el;
}

async function carregarPacientes() {
  const container = document.getElementById("lista-pacientes");
  const vazio = document.getElementById("lista-vazia");
  const semItens = document.getElementById("lista-sem-itens");
  const indice = document.getElementById("indice-alfabetico");
  vazio.classList.add("oculto");
  semItens.classList.add("oculto");
  document.getElementById("ordenar-pacientes").value = ordenacaoPacientesAtual;
  renderizarSkeleton(container);

  const todos = await invoke("list_patients", { busca: "" });

  container.innerHTML = "";
  indice.innerHTML = "";
  indice.classList.add("oculto");
  document.getElementById("lista-contagem").textContent = `${textoPacientes(todos.length)} ${todos.length === 1 ? "cadastrado" : "cadastrados"}`;

  renderizarFavoritos(todos);
  document.getElementById("favoritos-dica").classList.toggle("oculto", todos.some((p) => p.favorito));

  if (todos.length === 0) {
    document.getElementById("filtro-tags").innerHTML = "";
    vazio.classList.remove("oculto");
    return;
  }

  renderizarCondicoes(todos);
  const hoje = hojeLocalStr();
  let lista = filtroTagAtual
    ? todos.filter((p) => listaDeTags(p.tags).some((t) => t.toLowerCase() === filtroTagAtual.toLowerCase()))
    : todos;

  const ehHoje = (p) => p.ultima_consulta && p.ultima_consulta.startsWith(hoje);
  const nHoje = lista.filter(ehHoje).length;
  const nSem = lista.filter((p) => !p.ultima_consulta).length;
  document.getElementById("aba-lista-todos").textContent = `Todos (${lista.length})`;
  document.getElementById("aba-lista-hoje").textContent = `Atendidos hoje (${nHoje})`;
  document.getElementById("aba-lista-sem").textContent = `Sem atendimento (${nSem})`;
  document.querySelectorAll(".aba-lista").forEach((b) => {
    b.classList.toggle("ativa", b.dataset.abaLista === abaListaAtual);
    b.setAttribute("aria-selected", b.dataset.abaLista === abaListaAtual ? "true" : "false");
  });

  if (abaListaAtual === "hoje") lista = lista.filter(ehHoje);
  else if (abaListaAtual === "sem") lista = lista.filter((p) => !p.ultima_consulta);

  if (lista.length === 0) {
    semItens.classList.remove("oculto");
    return;
  }

  if (ordenacaoPacientesAtual === "ultima") {
    lista = [...lista].sort((a, b) => (b.ultima_consulta || "").localeCompare(a.ultima_consulta || "") || a.nome.localeCompare(b.nome, "pt-BR"));
    const grupos = [
      { titulo: "Hoje", detalhe: () => formatarData(hoje), itens: lista.filter(ehHoje) },
      { titulo: "Esta semana", itens: lista.filter((p) => p.ultima_consulta && !ehHoje(p) && diasDesde(p.ultima_consulta) < 7) },
      { titulo: "Anteriores", itens: lista.filter((p) => p.ultima_consulta && !ehHoje(p) && diasDesde(p.ultima_consulta) >= 7) },
      { titulo: "Sem atendimento", detalheFixo: "cadastrados, ainda não atendidos", itens: lista.filter((p) => !p.ultima_consulta) },
    ];
    for (const g of grupos) {
      if (!g.itens.length) continue;
      const detalhe = g.detalhe ? g.detalhe() : g.detalheFixo ? g.detalheFixo : textoPacientes(g.itens.length);
      const bloco = document.createElement("section");
      bloco.className = "grupo-pacientes";
      bloco.appendChild(cabecalhoGrupo(g.titulo, detalhe));
      g.itens.forEach((p) => bloco.appendChild(criarLinhaPaciente(p, hoje)));
      container.appendChild(bloco);
    }
    return;
  }

  // Ordem alfabética, com índice de letras quando a lista é grande
  lista = [...lista].sort((a, b) => a.nome.localeCompare(b.nome, "pt-BR"));
  const usarIndice = lista.length > 10;
  const letrasVistas = [];
  let letraAtual = null;
  let bloco = null;
  for (const p of lista) {
    const letra = (p.nome[0] || "?").toUpperCase();
    if (letra !== letraAtual) {
      letraAtual = letra;
      letrasVistas.push(letra);
      bloco = document.createElement("section");
      bloco.className = "grupo-pacientes";
      bloco.id = `letra-${letra}`;
      bloco.appendChild(cabecalhoGrupo(letra, ""));
      container.appendChild(bloco);
    }
    bloco.appendChild(criarLinhaPaciente(p, hoje));
  }
  if (usarIndice && letrasVistas.length > 1) {
    indice.innerHTML = letrasVistas.map((l) => `<button data-letra="${l}">${l}</button>`).join("");
    indice.querySelectorAll("button").forEach((b) => {
      b.addEventListener("click", () => {
        document.getElementById(`letra-${b.dataset.letra}`)?.scrollIntoView({ block: "start" });
      });
    });
    indice.classList.remove("oculto");
  }
}

document.querySelectorAll(".aba-lista").forEach((b) => {
  b.addEventListener("click", () => {
    abaListaAtual = b.dataset.abaLista;
    carregarPacientes();
  });
});

document.getElementById("ordenar-pacientes").addEventListener("change", (e) => {
  ordenacaoPacientesAtual = e.target.value;
  carregarPacientes();
});

document.getElementById("btn-novo-paciente").addEventListener("click", () => {
  abrirCadastro(null);
});

// ---------- Busca (sugestão flutuante) ----------

let buscaTimeout;
const buscaDropdown = document.getElementById("busca-sugestoes");

campoBusca.addEventListener("input", (e) => {
  clearTimeout(buscaTimeout);
  const valor = e.target.value;
  buscaTimeout = setTimeout(() => atualizarSugestoesBusca(valor), 150);
});

async function atualizarSugestoesBusca(valor) {
  if (!valor.trim()) {
    buscaDropdown.classList.add("oculto");
    buscaDropdown.innerHTML = "";
    return;
  }
  const resultados = await invoke("list_patients", { busca: valor });
  if (resultados.length === 0) {
    buscaDropdown.innerHTML = `<div class="sugestao-vazio">Nenhum paciente encontrado</div>`;
  } else {
    buscaDropdown.innerHTML = "";
    resultados.slice(0, 8).forEach((p) => {
      const item = document.createElement("div");
      item.className = "sugestao-item";
      item.innerHTML = `
        <div class="avatar-paciente" style="width:30px;height:30px;font-size:11px;background-color:${corAvatar(p.nome)}">${iniciais(p.nome)}</div>
        <div>
          <div class="nome">${escapeHtml(p.nome)}</div>
          <div class="meta">${escapeHtml(p.telefone || "Sem telefone")}</div>
        </div>
      `;
      item.addEventListener("click", () => {
        campoBusca.value = "";
        buscaDropdown.classList.add("oculto");
        abrirFicha(p.id);
      });
      buscaDropdown.appendChild(item);
    });
  }
  buscaDropdown.classList.remove("oculto");
}

document.addEventListener("click", (e) => {
  if (!buscaDropdown.contains(e.target) && e.target !== campoBusca) {
    buscaDropdown.classList.add("oculto");
  }
});
campoBusca.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    buscaDropdown.classList.add("oculto");
    campoBusca.blur();
  }
});

// ---------- TELA: Cadastro / edição de paciente ----------

let tagsEdicao = [];

function renderizarChipsEdicao() {
  const el = document.getElementById("tags-chips");
  el.innerHTML = "";
  tagsEdicao.forEach((t, i) => {
    const chip = document.createElement("span");
    chip.className = "tag-chip";
    chip.appendChild(document.createTextNode(t));
    const x = document.createElement("button");
    x.type = "button";
    x.title = "Remover etiqueta";
    x.textContent = "×";
    x.addEventListener("click", () => { tagsEdicao.splice(i, 1); renderizarChipsEdicao(); });
    chip.appendChild(x);
    el.appendChild(chip);
  });
}

function adicionarTagDigitada() {
  const campo = document.getElementById("p-tags-input");
  const t = campo.value.replace(/\|/g, " ").trim().slice(0, 30);
  campo.value = "";
  if (!t) return;
  if (!tagsEdicao.some((x) => x.toLowerCase() === t.toLowerCase())) tagsEdicao.push(t);
  renderizarChipsEdicao();
}

(function () {
  const campo = document.getElementById("p-tags-input");
  campo.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === ",") { e.preventDefault(); adicionarTagDigitada(); }
    else if (e.key === "Backspace" && !campo.value && tagsEdicao.length) { tagsEdicao.pop(); renderizarChipsEdicao(); }
  });
  campo.addEventListener("change", adicionarTagDigitada);
})();

async function abrirCadastro(idParaEditar) {
  const telaAtual = Object.entries(telas).find(([, el]) => !el.classList.contains("oculto"))[0];
  if (telaAtual !== "cadastro") {
    if (telaAtual === "ficha" && pacienteAtualId) origemCadastro = "ficha";
    else if (telaAtual === "inicio" || telaAtual === "recentes") origemCadastro = telaAtual;
    else origemCadastro = "lista";
  }
  const form = document.getElementById("form-paciente");
  form.reset();
  document.getElementById("paciente-id").value = "";
  document.getElementById("titulo-cadastro").textContent = "Novo paciente";
  document.getElementById("erro-nome").classList.add("oculto");
  document.getElementById("p-nome").classList.remove("campo-invalido");
  document.getElementById("aviso-cpf").classList.add("oculto");
  tagsEdicao = [];
  document.getElementById("p-tags-input").value = "";
  try {
    const todas = await invoke("list_all_tags");
    document.getElementById("tags-sugestoes").innerHTML = todas.map((t) => `<option value="${escapeHtml(t.nome)}"></option>`).join("");
  } catch (_) {}

  if (idParaEditar) {
    const p = await invoke("get_patient", { id: idParaEditar });
    document.getElementById("titulo-cadastro").textContent = "Editar paciente";
    document.getElementById("paciente-id").value = p.id;
    document.getElementById("p-nome").value = p.nome;
    document.getElementById("p-telefone").value = p.telefone;
    document.getElementById("p-telefone2").value = p.telefone2;
    document.getElementById("p-documento").value = p.documento;
    document.getElementById("p-nascimento").value = p.data_nascimento;
    document.getElementById("p-profissao").value = p.profissao;
    document.getElementById("p-endereco").value = p.endereco;
    document.getElementById("p-numero").value = p.numero;
    document.getElementById("p-complemento").value = p.complemento;
    document.getElementById("p-bairro").value = p.bairro;
    document.getElementById("p-municipio").value = p.municipio;
    document.getElementById("p-uf").value = p.uf;
    document.getElementById("p-sexo").value = p.sexo;
    document.getElementById("p-observacoes").value = p.observacoes;
    tagsEdicao = listaDeTags(p.tags);
    setBreadcrumb([
      { text: "Pacientes", onClick: irParaListaPacientes },
      { text: p.nome, onClick: () => abrirFicha(idParaEditar) },
      { text: "Editar" },
    ]);
  } else {
    document.getElementById("p-municipio").value = "Nova Friburgo";
    document.getElementById("p-uf").value = "RJ";
    setBreadcrumb([{ text: "Pacientes", onClick: irParaListaPacientes }, { text: "Novo paciente" }]);
  }

  renderizarChipsEdicao();
  mostrarTela("cadastro");
  reajustarTodasAsCaixas("#form-paciente textarea");
  if (!idParaEditar) {
    document.getElementById("nav-novo-paciente").classList.add("ativo");
  }
}

document.getElementById("form-paciente").addEventListener("submit", async (e) => {
  e.preventDefault();

  const id = document.getElementById("paciente-id").value;
  adicionarTagDigitada();
  const dados = {
    nome: document.getElementById("p-nome").value.trim().toUpperCase(),
    telefone: document.getElementById("p-telefone").value.trim(),
    telefone2: document.getElementById("p-telefone2").value.trim(),
    documento: document.getElementById("p-documento").value.trim(),
    dataNascimento: document.getElementById("p-nascimento").value,
    profissao: document.getElementById("p-profissao").value.trim(),
    endereco: document.getElementById("p-endereco").value.trim(),
    numero: document.getElementById("p-numero").value.trim(),
    complemento: document.getElementById("p-complemento").value.trim(),
    bairro: document.getElementById("p-bairro").value.trim(),
    municipio: document.getElementById("p-municipio").value.trim(),
    uf: document.getElementById("p-uf").value.trim().toUpperCase(),
    sexo: document.getElementById("p-sexo").value,
    observacoes: document.getElementById("p-observacoes").value.trim(),
  };

  if (!dados.nome) {
    document.getElementById("erro-nome").classList.remove("oculto");
    document.getElementById("p-nome").classList.add("campo-invalido");
    document.getElementById("p-nome").focus();
    return;
  }

  if (id) {
    await invoke("update_patient", {
      id,
      nome: dados.nome,
      telefone: dados.telefone,
      telefone2: dados.telefone2,
      documento: dados.documento,
      dataNascimento: dados.dataNascimento,
      profissao: dados.profissao,
      endereco: dados.endereco,
      numero: dados.numero,
      complemento: dados.complemento,
      bairro: dados.bairro,
      municipio: dados.municipio,
      uf: dados.uf,
      sexo: dados.sexo,
      observacoes: dados.observacoes,
    });
    await invoke("set_patient_tags", { id, tags: tagsEdicao.join("|") });
    mostrarToast("Paciente atualizado com sucesso");
    await abrirFicha(id);
  } else {
    const novoId = await invoke("add_patient", {
      nome: dados.nome,
      telefone: dados.telefone,
      telefone2: dados.telefone2,
      documento: dados.documento,
      dataNascimento: dados.dataNascimento,
      profissao: dados.profissao,
      endereco: dados.endereco,
      numero: dados.numero,
      complemento: dados.complemento,
      bairro: dados.bairro,
      municipio: dados.municipio,
      uf: dados.uf,
      sexo: dados.sexo,
      observacoes: dados.observacoes,
    });
    await invoke("set_patient_tags", { id: novoId, tags: tagsEdicao.join("|") });
    mostrarToast("Paciente cadastrado com sucesso");
    await abrirFicha(novoId);
  }
});

function voltarDoCadastro() {
  if (origemCadastro === "ficha" && pacienteAtualId) {
    abrirFicha(pacienteAtualId);
  } else if (origemCadastro === "inicio") {
    pacienteAtualId = null;
    mostrarTela("inicio");
    carregarInicio();
  } else if (origemCadastro === "recentes") {
    pacienteAtualId = null;
    mostrarTela("recentes");
    carregarRecentes();
  } else {
    pacienteAtualId = null;
    setBreadcrumb([{ text: "Pacientes" }]);
    mostrarTela("lista");
    carregarPacientes();
  }
}

document.getElementById("btn-cancelar-cadastro").addEventListener("click", voltarDoCadastro);

// ---------- TELA: Ficha do paciente ----------

async function abrirFicha(id) {
  pacienteAtualId = id;
  const p = await invoke("get_patient", { id });

  document.getElementById("ficha-nome").textContent = p.nome;
  setBreadcrumb([{ text: "Pacientes", onClick: irParaListaPacientes }, { text: p.nome }]);

  const btnFav = document.getElementById("btn-favoritar");
  btnFav.classList.toggle("ativo", p.favorito);
  btnFav.onclick = async () => {
    await invoke("toggle_favorito", { id, favorito: !p.favorito });
    await abrirFicha(id);
  };

  const idade = calcularIdade(p.data_nascimento);
  const badgeIdade = document.getElementById("ficha-idade-badge");
  if (idade !== null) {
    badgeIdade.textContent = `${idade} anos`;
    badgeIdade.classList.remove("oculto");
  } else {
    badgeIdade.classList.add("oculto");
  }

  const boxTags = document.getElementById("ficha-tags");
  boxTags.innerHTML = htmlChipsTags(p.tags);
  boxTags.classList.toggle("oculto", !p.tags);

  const itensDados = [
    ["Telefone", p.telefone, false, "destaque"],
    ["Telefone 2", p.telefone2],
    ["Documento", p.documento],
    ["Nascimento", p.data_nascimento ? formatarData(p.data_nascimento) : ""],
    ["Profissão", p.profissao],
    ["Endereço", enderecoCompleto(p), true, "endereco"],
  ].filter(([, valor]) => valor);

  document.getElementById("ficha-dados").innerHTML = itensDados.length
    ? itensDados
        .map(
          ([label, valor, largo, estilo]) => `
      <div class="ficha-dado-item${largo ? " largo" : ""}${estilo ? " " + estilo : ""}">
        <label>${label}</label>
        <span>${escapeHtml(valor)}</span>
      </div>
    `
        )
        .join("")
    : '<p class="ficha-timestamps" style="border:none;margin:0;padding:0">Nenhum dado pessoal informado.</p>';

  prepararObservacaoFixa(p);
  document.getElementById("resumo-desde").textContent = p.criado_em ? formatarData(p.criado_em.slice(0, 10)) : "—";
  selecionarAbaFicha("atendimentos");
  document.getElementById("historico-busca").value = "";
  fecharMenusSuspensos();

  document.getElementById("ficha-timestamps").textContent =
    `Cadastrado em ${formatarDataHora(p.criado_em)} · Atualizado em ${formatarDataHora(p.atualizado_em)}`;

  document.getElementById("btn-editar-paciente").onclick = () => abrirCadastro(id);
  document.getElementById("btn-novo-atendimento").onclick = () => abrirNovoAtendimento(id);
  document.getElementById("btn-exportar-historico").onclick = () => exportarHistoricoCompleto(id, p);
  document.getElementById("btn-novo-documento-ficha").onclick = () => abrirModalDocumento(p);
  document.getElementById("btn-excluir-paciente").onclick = async () => {
    const confirmar = await confirmarAcao(
      `Tem certeza que deseja excluir o cadastro de ${p.nome}? Todos os atendimentos registrados também serão apagados. Essa ação não pode ser desfeita.`
    );
    if (!confirmar) return;

    await invoke("delete_patient", { id });
    mostrarToast("Paciente excluído");
    pacienteAtualId = null;
    setBreadcrumb([{ text: "Pacientes" }]);
    mostrarTela("lista");
    carregarPacientes();
  };

  await carregarAtendimentos(id);
  await carregarDocumentos(p);
  mostrarTela("ficha");
}

let atendimentosFichaAtual = [];

function textoHaDias(dataStr) {
  const d = diasDesde(dataStr);
  if (!isFinite(d)) return "";
  if (d <= 0) return "hoje";
  if (d === 1) return "ontem";
  if (d < 60) return `há ${d} dias`;
  if (d < 365) return `há ${Math.floor(d / 30)} meses`;
  const anos = Math.floor(d / 365);
  return anos === 1 ? "há 1 ano" : `há ${anos} anos`;
}

function normalizarBusca(s) {
  return (s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

async function carregarAtendimentos(pacienteId) {
  const container = document.getElementById("lista-atendimentos");
  renderizarSkeleton(container, 2);
  atendimentosFichaAtual = await invoke("list_visits", { pacienteId });
  renderizarHistorico();
}

function renderizarHistorico() {
  const container = document.getElementById("lista-atendimentos");
  const vazio = document.getElementById("atendimentos-vazio");
  const semResultado = document.getElementById("atendimentos-sem-resultado");
  const contador = document.getElementById("historico-contador");
  const todos = atendimentosFichaAtual;
  const termo = normalizarBusca(document.getElementById("historico-busca").value.trim());

  container.innerHTML = "";
  vazio.classList.add("oculto");
  semResultado.classList.add("oculto");
  document.getElementById("aba-atendimentos").textContent = `Atendimentos (${todos.length})`;

  const ultimo = document.getElementById("resumo-ultimo");
  ultimo.textContent = todos.length ? `${formatarData(todos[0].data)} · ${textoHaDias(todos[0].data)}` : "—";

  if (todos.length === 0) {
    contador.innerHTML = "";
    document.querySelector(".historico-busca").classList.add("oculto");
    vazio.classList.remove("oculto");
    return;
  }
  document.querySelector(".historico-busca").classList.remove("oculto");

  const filtrados = termo
    ? todos.filter((a) =>
        normalizarBusca(`${a.resumo} ${a.trecho} ${a.tipo_atendimento} ${formatarData(a.data)}`).includes(termo)
      )
    : todos;

  const maisAntigo = todos[todos.length - 1].data;
  contador.innerHTML = termo
    ? `<strong>${filtrados.length}</strong> de ${todos.length} atendimentos`
    : `<strong>${todos.length} ${todos.length === 1 ? "atendimento" : "atendimentos"}</strong> desde ${formatarData(maisAntigo)}`;

  if (filtrados.length === 0) {
    semResultado.classList.remove("oculto");
    return;
  }

  const grupos = [];
  for (const a of filtrados) {
    const dia = a.data.split(" ")[0];
    let g = grupos[grupos.length - 1];
    if (!g || g.dia !== dia) {
      g = { dia, itens: [] };
      grupos.push(g);
    }
    g.itens.push(a);
  }

  for (const g of grupos) {
    const bloco = document.createElement("section");
    bloco.className = "dia-grupo";
    const cab = document.createElement("div");
    cab.className = "dia-cabecalho";
    const extra = [textoHaDias(g.dia), g.itens.length > 1 ? `${g.itens.length} atendimentos` : ""].filter(Boolean).join(" · ");
    cab.innerHTML = `<strong>${formatarData(g.dia)}</strong><span>${extra}</span>`;
    bloco.appendChild(cab);

    for (const a of g.itens) {
      const hora = (a.data.split(" ")[1] || "").slice(0, 5);
      const linha = document.createElement("div");
      linha.className = "atend-linha";
      linha.tabIndex = 0;
      linha.innerHTML = `
        <div class="atend-hora">${escapeHtml(hora)}</div>
        <div class="atend-corpo">
          <div class="atend-titulo">
            <span>${escapeHtml(a.resumo || "Atendimento")}</span>
            ${tagTipoAtendimento(a.tipo_atendimento)}
            ${a.resumo ? "" : '<span class="pill-sem-diag">sem diagnóstico</span>'}
          </div>
          ${a.trecho ? `<p class="atend-texto">${escapeHtml(a.trecho)}</p>` : ""}
        </div>
      `;
      linha.addEventListener("click", () => abrirAtendimento(a.id));
      linha.addEventListener("keydown", (e) => {
        if (e.key === "Enter") abrirAtendimento(a.id);
      });
      bloco.appendChild(linha);
    }
    container.appendChild(bloco);
  }
}

document.getElementById("historico-busca").addEventListener("input", renderizarHistorico);
document.getElementById("ficha-voltar").addEventListener("click", () => irParaListaPacientes());

// ----- Abas da ficha -----
function selecionarAbaFicha(nome) {
  document.querySelectorAll(".aba-ficha").forEach((b) => {
    const ativa = b.dataset.aba === nome;
    b.classList.toggle("ativa", ativa);
    b.setAttribute("aria-selected", ativa ? "true" : "false");
  });
  ["atendimentos", "documentos", "anexos"].forEach((n) => {
    document.getElementById(`painel-${n}`).classList.toggle("oculto", n !== nome);
  });
}
document.querySelectorAll(".aba-ficha").forEach((b) => {
  b.addEventListener("click", () => selecionarAbaFicha(b.dataset.aba));
});

// ----- Menus suspensos (Documentos ▾ e ⋯) -----
function fecharMenusSuspensos() {
  document.querySelectorAll(".menu-suspenso-lista").forEach((m) => m.classList.add("oculto"));
  document.querySelectorAll(".menu-suspenso > button").forEach((b) => b.setAttribute("aria-expanded", "false"));
}
[["btn-menu-documentos", "menu-documentos"], ["btn-menu-mais", "menu-mais"]].forEach(([btnId, menuId]) => {
  document.getElementById(btnId).addEventListener("click", (e) => {
    e.stopPropagation();
    const menu = document.getElementById(menuId);
    const abrir = menu.classList.contains("oculto");
    fecharMenusSuspensos();
    if (abrir) {
      menu.classList.remove("oculto");
      document.getElementById(btnId).setAttribute("aria-expanded", "true");
    }
  });
});
document.querySelectorAll(".menu-suspenso-lista button").forEach((b) => b.addEventListener("click", fecharMenusSuspensos));
document.addEventListener("click", fecharMenusSuspensos);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") fecharMenusSuspensos();
});

// ----- Observação fixa -----
let observacaoFixaPacienteId = null;

function mostrarObservacaoFixa(texto) {
  const el = document.getElementById("obs-fixa-texto");
  el.textContent = texto || "Nenhuma observação fixa. Clique no lápis para adicionar.";
  el.classList.toggle("vazio", !texto);
  document.getElementById("obs-fixa-edicao").classList.add("oculto");
  el.classList.remove("oculto");
}

function prepararObservacaoFixa(p) {
  observacaoFixaPacienteId = p.id;
  document.getElementById("obs-fixa-input").value = p.observacao_fixa || "";
  mostrarObservacaoFixa(p.observacao_fixa || "");
}

document.getElementById("btn-obs-fixa-editar").addEventListener("click", () => {
  document.getElementById("obs-fixa-texto").classList.add("oculto");
  document.getElementById("obs-fixa-edicao").classList.remove("oculto");
  document.getElementById("obs-fixa-input").focus();
});
document.getElementById("btn-obs-fixa-cancelar").addEventListener("click", async () => {
  const p = await invoke("get_patient", { id: observacaoFixaPacienteId });
  prepararObservacaoFixa(p);
});
document.getElementById("btn-obs-fixa-salvar").addEventListener("click", async () => {
  const texto = document.getElementById("obs-fixa-input").value.trim();
  await invoke("set_observacao_fixa", { id: observacaoFixaPacienteId, texto });
  mostrarObservacaoFixa(texto);
  mostrarToast("Observação salva");
});

// ---------- Acordeão: dados cadastrais do paciente (na tela de atendimento) ----------

const acordeaoToggle = document.getElementById("acordeao-toggle");
const acordeaoCorpo = document.getElementById("acordeao-corpo");
const acordeaoSeta = document.getElementById("acordeao-seta");

acordeaoToggle.addEventListener("click", () => {
  const aberto = !acordeaoCorpo.classList.contains("oculto");
  if (aberto) {
    acordeaoCorpo.classList.add("oculto");
    acordeaoSeta.classList.remove("aberta");
  } else {
    acordeaoCorpo.classList.remove("oculto");
    acordeaoSeta.classList.add("aberta");
  }
});

function enderecoResumido(p) {
  if (!p) return "";
  let linha = p.endereco || "";
  if (p.numero) linha += (linha ? ", " : "") + p.numero;
  if (p.bairro) linha += (linha ? " - " : "") + p.bairro;
  return linha;
}

function enderecoCompleto(p) {
  if (!p) return "";
  let linha1 = p.endereco || "";
  if (p.numero) linha1 += (linha1 ? ", " : "") + p.numero;
  if (p.complemento) linha1 += (linha1 ? " - " : "") + p.complemento;
  const partes = [];
  if (linha1) partes.push(linha1);
  if (p.bairro) partes.push(p.bairro);
  const cidadeUf = [p.municipio, p.uf].filter(Boolean).join("/");
  if (cidadeUf) partes.push(cidadeUf);
  return partes.join(" - ");
}

let pacienteAtendimentoAtual = null; // guarda os dados do paciente carregados para o atendimento aberto

async function preencherAcordeaoPaciente(pacienteId) {
  const p = await invoke("get_patient", { id: pacienteId });
  pacienteAtendimentoAtual = p;

  document.getElementById("acc-telefone").textContent = p.telefone || "—";
  document.getElementById("acc-documento").textContent = p.documento || "—";
  document.getElementById("acc-nascimento").textContent = p.data_nascimento ? formatarData(p.data_nascimento) : "—";
  document.getElementById("acc-profissao").textContent = p.profissao || "—";
  document.getElementById("acc-endereco").textContent = enderecoCompleto(p) || "—";
  document.getElementById("acc-observacoes").textContent = p.observacoes || "—";

  acordeaoCorpo.classList.add("oculto");
  acordeaoSeta.classList.remove("aberta");

  // Cabeçalho tipo "prontuário" com nome e idade
  document.getElementById("atendimento-paciente-nome").textContent = p.nome;
  const idade = calcularIdade(p.data_nascimento);
  const badge = document.getElementById("atendimento-idade-badge");
  if (idade !== null) {
    badge.textContent = `${idade} anos`;
    badge.classList.remove("oculto");
  } else {
    badge.classList.add("oculto");
  }
}

// ---------- Campos recorrentes (herdados do atendimento anterior) ----------

function aplicarCampoRecorrente(idCampo, idDica, valor) {
  if (!valor || !valor.trim()) return;
  const campo = document.getElementById(idCampo);
  const dica = document.getElementById(idDica);
  campo.value = valor;
  dica.classList.remove("oculto");

  const esconderDica = () => {
    dica.classList.add("oculto");
    campo.removeEventListener("input", esconderDica);
  };
  campo.addEventListener("input", esconderDica);
}

async function preencherCamposRecorrentes(pacienteId) {
  const dados = await invoke("get_dados_recorrentes", { pacienteId });
  if (!dados) return;
  aplicarCampoRecorrente("a-hpp", "dica-hpp", dados.hpp);
  aplicarCampoRecorrente("a-historia-familiar", "dica-historia-familiar", dados.historia_familiar);
  aplicarCampoRecorrente("a-alergias", "dica-alergias", dados.alergias);
  aplicarCampoRecorrente("a-medicacao", "dica-medicacao", dados.medicacao_uso);
  aplicarCampoRecorrente("a-diagnostico-previo", "dica-diagnostico-previo", dados.diagnostico_previo);
}

// ---------- Rascunho automático (protege contra perda de dados) ----------

let contextoRascunho = null; // pacienteId quando estamos num "novo atendimento"; null em edição/visualização
let rascunhoTimeout;

function chaveRascunho(pacienteId) {
  return `prontuario-rascunho-${pacienteId}`;
}

function salvarRascunho() {
  if (!contextoRascunho) return;
  const dados = coletarDadosFormAtendimento();
  const temConteudo = Object.values(dados).some((v) => v && v.trim());
  if (!temConteudo) return;
  localStorage.setItem(chaveRascunho(contextoRascunho), JSON.stringify(dados));
}

function agendarRascunho() {
  if (!contextoRascunho) return;
  clearTimeout(rascunhoTimeout);
  rascunhoTimeout = setTimeout(salvarRascunho, 1000);
}

function limparRascunho(pacienteId) {
  localStorage.removeItem(chaveRascunho(pacienteId));
}

async function verificarRascunho(pacienteId) {
  const bruto = localStorage.getItem(chaveRascunho(pacienteId));
  if (!bruto) return;
  let dados;
  try {
    dados = JSON.parse(bruto);
  } catch {
    limparRascunho(pacienteId);
    return;
  }
  const continuar = await confirmarAcao(
    "Encontramos um rascunho não salvo deste paciente. Deseja continuar de onde parou?"
  );
  if (!continuar) {
    limparRascunho(pacienteId);
    return;
  }
  document.getElementById("a-primeira-consulta").value = dados.primeiraConsulta || "";
  document.getElementById("a-hpp").value = dados.hpp || "";
  document.getElementById("a-historia-familiar").value = dados.historiaFamiliar || "";
  document.getElementById("a-alergias").value = dados.alergias || "";
  document.getElementById("a-medicacao").value = dados.medicacaoUso || "";
  document.getElementById("a-exame").value = dados.exameFisico || "";
  document.getElementById("a-cid").value = dados.cid || "";
  atualizarDescricaoCidSelecionada();
  document.getElementById("a-diagnostico-atual").value = dados.diagnosticoAtual || "";
  document.getElementById("a-diagnostico-previo").value = dados.diagnosticoPrevio || "";
  document.getElementById("a-resultado-exames").value = dados.resultadoExames || "";
  document.getElementById("a-conduta").value = dados.conduta || "";
  formAtendimentoSujo = true;
}

// ---------- TELA: Novo / visualizar atendimento ----------

let formAtendimentoSujo = false;
let atendimentoEmEdicaoId = null;

function selecionarTipoAtendimento(valor) {
  document.getElementById("a-tipo-atendimento").value = valor || "";
  document.querySelectorAll(".pill-tipo").forEach((p) => {
    p.classList.toggle("ativo", p.dataset.valor === valor);
  });
}

document.querySelectorAll(".pill-tipo").forEach((p) => {
  p.addEventListener("click", () => {
    const mesmoValor = document.getElementById("a-tipo-atendimento").value === p.dataset.valor;
    selecionarTipoAtendimento(mesmoValor ? "" : p.dataset.valor);
    marcarFormSujo();
  });
});

function tagTipoAtendimento(tipo) {
  if (tipo === "1ª vez") return '<span class="tag-tipo-atendimento tag-primeira">1ª vez</span>';
  if (tipo === "Retorno") return '<span class="tag-tipo-atendimento tag-retorno">Retorno</span>';
  if (tipo === "Urgência") return '<span class="tag-tipo-atendimento tag-urgencia">Urgência</span>';
  return "";
}

// ---------- Autocomplete de CID-10 ----------

function buscarCid10(query) {
  const q = (query || "").trim().toLowerCase();
  if (q.length < 2 || typeof CID10_LISTA === "undefined") return [];
  const qSemPonto = q.replace(/\./g, "");
  const qEscapado = q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const regexPalavra = new RegExp(`(^|[^a-zà-ÿ])${qEscapado}`, "i");

  const porCodigo = [];
  const descInicio = [];
  const descPalavra = [];
  const descSubstring = [];

  for (const item of CID10_LISTA) {
    const [codigo, descricaoOriginal] = item;
    const descricao = descricaoOriginal.toLowerCase();
    if (codigo.toLowerCase().replace(/\./g, "").startsWith(qSemPonto)) {
      if (porCodigo.length < 40) porCodigo.push(item);
    } else if (descricao.startsWith(q)) {
      if (descInicio.length < 40) descInicio.push(item);
    } else if (regexPalavra.test(descricao)) {
      if (descPalavra.length < 40) descPalavra.push(item);
    } else if (descricao.includes(q)) {
      if (descSubstring.length < 40) descSubstring.push(item);
    }
  }
  return porCodigo.concat(descInicio, descPalavra, descSubstring).slice(0, 40);
}

function renderizarSugestoesCid(matches) {
  const caixa = document.getElementById("a-cid-sugestoes");
  if (!caixa) return;
  if (!matches.length) {
    caixa.classList.add("oculto");
    caixa.innerHTML = "";
    return;
  }
  caixa.innerHTML = matches
    .map(
      ([codigo, descricao]) => `
      <div class="cid-sugestao-item" data-codigo="${escapeHtml(codigo)}">
        <span class="cid-sugestao-codigo">${escapeHtml(codigo)}</span>
        <span class="cid-sugestao-desc">${escapeHtml(descricao)}</span>
      </div>
    `
    )
    .join("");
  caixa.classList.remove("oculto");
}

function atualizarDescricaoCidSelecionada() {
  const campo = document.getElementById("a-cid");
  const p = document.getElementById("a-cid-descricao");
  if (!campo || !p) return;
  const valor = campo.value.trim().toUpperCase();
  const match = typeof CID10_LISTA !== "undefined" ? CID10_LISTA.find(([codigo]) => codigo.toUpperCase() === valor) : null;
  if (match) {
    p.textContent = match[1];
    p.classList.remove("oculto");
  } else {
    p.textContent = "";
    p.classList.add("oculto");
  }
}

function inicializarAutocompleteCid() {
  const input = document.getElementById("a-cid");
  const caixa = document.getElementById("a-cid-sugestoes");
  if (!input || !caixa || input.dataset.autocompleteCidPronto) return;
  input.dataset.autocompleteCidPronto = "1";

  input.addEventListener("input", () => {
    renderizarSugestoesCid(buscarCid10(input.value));
    atualizarDescricaoCidSelecionada();
  });

  input.addEventListener("focus", () => {
    if (input.value.trim().length >= 2) {
      renderizarSugestoesCid(buscarCid10(input.value));
    }
  });

  input.addEventListener("blur", () => {
    setTimeout(() => caixa.classList.add("oculto"), 150);
  });

  caixa.addEventListener("mousedown", (e) => {
    const item = e.target.closest(".cid-sugestao-item");
    if (!item) return;
    e.preventDefault();
    input.value = item.dataset.codigo;
    caixa.classList.add("oculto");
    atualizarDescricaoCidSelecionada();
    marcarFormSujo();
  });
}

function limparFormAtendimento() {
  selecionarTipoAtendimento("");
  document.getElementById("a-primeira-consulta").value = "";
  document.getElementById("a-hpp").value = "";
  document.getElementById("a-historia-familiar").value = "";
  document.getElementById("a-alergias").value = "";
  document.getElementById("a-medicacao").value = "";
  document.getElementById("a-sv-fc").value = "";
  document.getElementById("a-sv-pa-sistolica").value = "";
  document.getElementById("a-sv-pa-diastolica").value = "";
  document.getElementById("a-sv-fr").value = "";
  document.getElementById("a-sv-temp").value = "";
  document.getElementById("a-sv-obs").value = "";
  document.getElementById("a-exame").value = "";
  document.getElementById("a-cid").value = "";
  document.getElementById("a-cid-sugestoes").classList.add("oculto");
  atualizarDescricaoCidSelecionada();
  document.getElementById("a-diagnostico-atual").value = "";
  document.getElementById("a-diagnostico-previo").value = "";
  document.getElementById("a-resultado-exames").value = "";
  document.getElementById("a-conduta").value = "";
  document.getElementById("dica-hpp").classList.add("oculto");
  document.getElementById("dica-historia-familiar").classList.add("oculto");
  document.getElementById("dica-alergias").classList.add("oculto");
  document.getElementById("dica-medicacao").classList.add("oculto");
  document.getElementById("dica-diagnostico-previo").classList.add("oculto");
}

function coletarDadosFormAtendimento() {
  return {
    tipoAtendimento: document.getElementById("a-tipo-atendimento").value,
    primeiraConsulta: document.getElementById("a-primeira-consulta").value.trim(),
    hpp: document.getElementById("a-hpp").value.trim(),
    historiaFamiliar: document.getElementById("a-historia-familiar").value.trim(),
    alergias: document.getElementById("a-alergias").value.trim(),
    medicacaoUso: document.getElementById("a-medicacao").value.trim(),
    exameFisico: document.getElementById("a-exame").value.trim(),
    frequenciaCardiaca: document.getElementById("a-sv-fc").value.trim(),
    pressaoSistolica: document.getElementById("a-sv-pa-sistolica").value.trim(),
    pressaoDiastolica: document.getElementById("a-sv-pa-diastolica").value.trim(),
    pressaoArterialMedia: "",
    frequenciaRespiratoria: document.getElementById("a-sv-fr").value.trim(),
    saturacaoO2: "",
    temperatura: document.getElementById("a-sv-temp").value.trim(),
    glicemia: "",
    momentoColeta: "",
    sinaisVitaisObs: document.getElementById("a-sv-obs").value.trim(),
    cid: document.getElementById("a-cid").value.trim().toUpperCase(),
    diagnosticoAtual: document.getElementById("a-diagnostico-atual").value.trim(),
    diagnosticoPrevio: document.getElementById("a-diagnostico-previo").value.trim(),
    resultadoExames: document.getElementById("a-resultado-exames").value.trim(),
    conduta: document.getElementById("a-conduta").value.trim(),
  };
}

function marcarFormSujo() {
  formAtendimentoSujo = true;
  agendarRascunho();
}

function ativarRastreioDeAlteracoes() {
  const form = document.getElementById("form-atendimento");
  form.querySelectorAll("textarea, .grade-sinais-vitais input, .campo-cid input").forEach((c) => {
    c.removeEventListener("input", marcarFormSujo);
    c.addEventListener("input", marcarFormSujo);
  });
}

async function abrirNovoAtendimento(pacienteId) {
  limparFormAtendimento();
  atendimentoEmEdicaoId = null;
  atendimentoDataAtual = null;
  contextoRascunho = pacienteId;
  pacienteAtualId = pacienteId;
  document.getElementById("atendimento-titulo").textContent = "Novo atendimento";

  await preencherAcordeaoPaciente(pacienteId);
  setBreadcrumb([
    { text: "Pacientes", onClick: irParaListaPacientes },
    { text: pacienteAtendimentoAtual.nome, onClick: () => abrirFicha(pacienteId) },
    { text: "Novo atendimento" },
  ]);

  const form = document.getElementById("form-atendimento");
  form.querySelectorAll("textarea, .grade-sinais-vitais input, .campo-cid input").forEach((c) => (c.disabled = false));
  document.querySelectorAll(".pill-tipo").forEach((p) => (p.disabled = false));
  document.getElementById("btn-salvar-atendimento").classList.remove("oculto");
  document.getElementById("btn-editar-atendimento").classList.add("oculto");

  form.onsubmit = async (e) => {
    e.preventDefault();
    const confirmar = await confirmarAcao("Confirma salvar este atendimento?");
    if (!confirmar) return;

    await invoke("add_visit", {
      pacienteId,
      ...coletarDadosFormAtendimento(),
    });
    limparRascunho(pacienteId);
    formAtendimentoSujo = false;
    mostrarToast("Atendimento salvo com sucesso");
    await abrirFicha(pacienteId);
  };

  formAtendimentoSujo = false;
  ativarRastreioDeAlteracoes();
  await preencherCamposRecorrentes(pacienteId);
  await verificarRascunho(pacienteId);
  document.getElementById("ex-data").value = new Date().toISOString().slice(0, 10);
  await carregarExamesEvolucao(pacienteId);
  mostrarTela("atendimento");
  reajustarTodasAsCaixas("#form-atendimento textarea");
}

function ativarModoEdicao(id, pacienteId) {
  atendimentoEmEdicaoId = id;
  contextoRascunho = null;
  const form = document.getElementById("form-atendimento");
  form.querySelectorAll("textarea, .grade-sinais-vitais input, .campo-cid input").forEach((c) => (c.disabled = false));
  document.querySelectorAll(".pill-tipo").forEach((p) => (p.disabled = false));
  document.getElementById("btn-salvar-atendimento").classList.remove("oculto");
  document.getElementById("btn-editar-atendimento").classList.add("oculto");

  form.onsubmit = async (e) => {
    e.preventDefault();
    const confirmar = await confirmarAcao("Confirma salvar as alterações neste atendimento?");
    if (!confirmar) return;

    await invoke("update_visit", {
      id,
      ...coletarDadosFormAtendimento(),
    });
    formAtendimentoSujo = false;
    mostrarToast("Alterações salvas com sucesso");
    await abrirFicha(pacienteId);
  };

  formAtendimentoSujo = false;
  ativarRastreioDeAlteracoes();
}

async function abrirAtendimento(id) {
  const a = await invoke("get_visit", { id });
  atendimentoEmEdicaoId = null;
  atendimentoDataAtual = a.data;
  pacienteAtualId = a.paciente_id;
  contextoRascunho = null;

  document.getElementById("atendimento-titulo").textContent = `Atendimento de ${formatarDataHoraAtendimento(a.data)}`;

  await preencherAcordeaoPaciente(a.paciente_id);
  setBreadcrumb([
    { text: "Pacientes", onClick: irParaListaPacientes },
    { text: pacienteAtendimentoAtual.nome, onClick: () => abrirFicha(a.paciente_id) },
    { text: `Atendimento de ${formatarDataHoraAtendimento(a.data)}` },
  ]);

  selecionarTipoAtendimento(a.tipo_atendimento || "");
  document.getElementById("a-primeira-consulta").value = a.primeira_consulta;
  document.getElementById("a-hpp").value = a.hpp;
  document.getElementById("a-historia-familiar").value = a.historia_familiar;
  document.getElementById("a-alergias").value = a.alergias;
  document.getElementById("a-medicacao").value = a.medicacao_uso;
  document.getElementById("dica-hpp").classList.add("oculto");
  document.getElementById("dica-historia-familiar").classList.add("oculto");
  document.getElementById("dica-alergias").classList.add("oculto");
  document.getElementById("dica-medicacao").classList.add("oculto");
  document.getElementById("dica-diagnostico-previo").classList.add("oculto");
  document.getElementById("a-sv-fc").value = a.frequencia_cardiaca || "";
  document.getElementById("a-sv-pa-sistolica").value = a.pressao_sistolica || "";
  document.getElementById("a-sv-pa-diastolica").value = a.pressao_diastolica || "";
  document.getElementById("a-sv-fr").value = a.frequencia_respiratoria || "";
  document.getElementById("a-sv-temp").value = a.temperatura || "";
  document.getElementById("a-sv-obs").value = a.sinais_vitais_obs || "";
  document.getElementById("a-exame").value = a.exame_fisico;
  document.getElementById("a-cid").value = a.cid || "";
  atualizarDescricaoCidSelecionada();
  document.getElementById("a-diagnostico-atual").value = a.diagnostico_atual;
  document.getElementById("a-diagnostico-previo").value = a.diagnostico_previo;
  document.getElementById("a-resultado-exames").value = a.resultado_exames;
  document.getElementById("a-conduta").value = a.conduta;

  const form = document.getElementById("form-atendimento");
  form.querySelectorAll("textarea, .grade-sinais-vitais input, .campo-cid input").forEach((c) => (c.disabled = true));
  document.querySelectorAll(".pill-tipo").forEach((p) => (p.disabled = true));
  document.getElementById("btn-salvar-atendimento").classList.add("oculto");
  document.getElementById("btn-editar-atendimento").classList.remove("oculto");
  form.onsubmit = (e) => e.preventDefault();

  document.getElementById("btn-editar-atendimento").onclick = () => {
    ativarModoEdicao(id, a.paciente_id);
  };

  formAtendimentoSujo = false;
  document.getElementById("ex-data").value = new Date().toISOString().slice(0, 10);
  await carregarExamesEvolucao(a.paciente_id);
  mostrarTela("atendimento");
  reajustarTodasAsCaixas("#form-atendimento textarea");
}

document.getElementById("btn-cancelar-atendimento").addEventListener("click", async () => {
  if (formAtendimentoSujo) {
    const sair = await confirmarAcao("Você tem alterações não salvas neste atendimento. Deseja realmente sair sem salvar?");
    if (!sair) return;
  }
  formAtendimentoSujo = false;
  abrirFicha(pacienteAtualId);
});

// ---------- Impressão / PDF do atendimento ----------

function montarFichaAtendimentoHtml(paciente, medico, dataLabel, tipoAtendimento, campos) {
  const m = medico || {};
  const idade = paciente ? calcularIdade(paciente.data_nascimento) : null;
  const registro = [m.crm, m.rqe].filter(Boolean).join(" - ");

  const secoes = campos
    .map(
      ([label, valor]) => `
      <div class="ficha-secao">
        <div class="ficha-secao-titulo">${escapeHtml(label)}</div>
        <div class="ficha-secao-corpo">${escapeHtml(valor) || "—"}</div>
      </div>
    `
    )
    .join("");

  return `
    <div class="ficha-impressao">
      <div class="ficha-topo">
        <div class="ficha-topo-medico">
          ${escapeHtml(m.nome || "")}
          <div class="ficha-registro">${registro ? escapeHtml(registro) : ""}${m.especialidade ? ` · ${escapeHtml(m.especialidade)}` : ""}</div>
        </div>
        <div class="ficha-topo-titulo">
          <h1>FICHA DE ATENDIMENTO</h1>
          <p>${escapeHtml(dataLabel)}</p>
          <div class="ficha-tag-wrap">${tagTipoAtendimento(tipoAtendimento)}</div>
        </div>
      </div>
      <div class="ficha-paciente">
        <div class="ficha-paciente-campo">
          <label>Paciente</label>
          <p>${paciente ? escapeHtml(paciente.nome) : "—"}</p>
        </div>
        <div class="ficha-paciente-campo">
          <label>Idade</label>
          <p>${idade !== null ? `${idade} anos` : "—"}</p>
        </div>
        <div class="ficha-paciente-campo">
          <label>CPF</label>
          <p>${paciente && paciente.documento ? escapeHtml(paciente.documento) : "—"}</p>
        </div>
      </div>
      <div class="ficha-secoes">
        ${secoes}
      </div>
    </div>
  `;
}

function montarResumoSinaisVitais(sv) {
  const s = sv || {};
  const partes = [];
  if (s.fc) partes.push(`FC: ${s.fc} bpm`);
  if (s.paSistolica || s.paDiastolica) partes.push(`PA: ${s.paSistolica || "—"}/${s.paDiastolica || "—"} mmHg`);
  if (s.fr) partes.push(`FR: ${s.fr} mpm`);
  if (s.temp) partes.push(`Temp: ${s.temp}°C`);
  const resumo = partes.join("   ·   ");
  const obs = (s.obs || "").trim();
  if (resumo && obs) return `${resumo}\n${obs}`;
  if (obs) return obs;
  return resumo;
}

function montarRodapeAssinaturaImpressao(medico) {
  const m = medico || {};
  const registro = [m.crm, m.rqe].filter(Boolean).join(" - ");
  const cidade = m.cidade || "Nova Friburgo";

  return `
    <div class="ficha-rodape-assinatura">
      <div class="ficha-rodape-assinatura-bloco">
        <div class="ficha-rodape-assinatura-linha"></div>
        <div class="ficha-rodape-assinatura-nome">${escapeHtml(m.nome || "")}</div>
        ${registro ? `<div>${escapeHtml(registro)}</div>` : ""}
      </div>
      <div class="ficha-rodape-assinatura-local">
        ${escapeHtml(cidade)}, ${dataPorExtenso()}
      </div>
    </div>
  `;
}

function montarCapaTransferencia(paciente, medico, visitas, agora) {
  const m = medico || {};
  const p = paciente || {};
  const idade = calcularIdade(p.data_nascimento);
  const registro = [m.crm, m.rqe].filter(Boolean).join(" - ");
  const primeira = visitas[0];
  const ultima = visitas[visitas.length - 1];

  const linhasDados = [
    `Nome completo: ${p.nome || "—"}`,
    `Data de nascimento: ${p.data_nascimento ? formatarData(p.data_nascimento) : "—"}${idade !== null ? ` (${idade} anos)` : ""}`,
    `Sexo: ${p.sexo || "—"}`,
    `CPF: ${p.documento || "—"}`,
    `Telefone: ${[p.telefone, p.telefone2].filter(Boolean).join(" / ") || "—"}`,
    `Endereço: ${enderecoCompleto(p) || "—"}`,
  ].join("\n");

  const textoDocumento =
    `Este documento reúne o resumo cronológico de ${visitas.length} atendimento${visitas.length === 1 ? "" : "s"} ` +
    `realizado${visitas.length === 1 ? "" : "s"} entre ${formatarDataHoraAtendimento(primeira.data)} e ${formatarDataHoraAtendimento(ultima.data)}, ` +
    `emitido a pedido do paciente (ou responsável) para fins de continuidade do cuidado em transferência para outro ` +
    `profissional ou serviço de saúde.`;

  return `
    <div class="ficha-impressao ficha-capa">
      <div class="ficha-topo">
        <div class="ficha-topo-medico">
          ${escapeHtml(m.nome || "")}
          <div class="ficha-registro">${registro ? escapeHtml(registro) : ""}${m.especialidade ? ` · ${escapeHtml(m.especialidade)}` : ""}</div>
        </div>
        <div class="ficha-topo-titulo">
          <h1>RESUMO DE PRONTUÁRIO — TRANSFERÊNCIA DE CUIDADO</h1>
          <p>Emitido em ${escapeHtml(agora)}</p>
        </div>
      </div>
      <div class="ficha-secoes">
        <div class="ficha-secao">
          <div class="ficha-secao-titulo">Dados do paciente</div>
          <div class="ficha-secao-corpo">${escapeHtml(linhasDados)}</div>
        </div>
        <div class="ficha-secao">
          <div class="ficha-secao-titulo">Sobre este documento</div>
          <div class="ficha-secao-corpo">${escapeHtml(textoDocumento)}</div>
        </div>
      </div>
    </div>
  `;
}

async function exportarHistoricoCompleto(pacienteId, paciente) {
  const visitas = await invoke("list_visits_completos", { pacienteId });
  if (visitas.length === 0) {
    mostrarToast("Este paciente ainda não tem atendimentos registrados");
    return;
  }

  const medico = await invoke("get_medico_config");
  const agora = new Date().toLocaleString("pt-BR");

  const camposDe = (v) => [
    ["Consulta", v.primeira_consulta],
    ["Sinais vitais", montarResumoSinaisVitais({
      fc: v.frequencia_cardiaca,
      paSistolica: v.pressao_sistolica,
      paDiastolica: v.pressao_diastolica,
      fr: v.frequencia_respiratoria,
      temp: v.temperatura,
      obs: v.sinais_vitais_obs,
    })],
    ["HPP (História Patológica Pregressa)", v.hpp],
    ["História familiar", v.historia_familiar],
    ["Alergias", v.alergias],
    ["Medicação em uso", v.medicacao_uso],
    ["Exame físico", v.exame_fisico],
    ["CID (diagnóstico padronizado)", v.cid],
    ["Diagnóstico atual", v.diagnostico_atual],
    ["Diagnóstico prévio", v.diagnostico_previo],
    ["Resultado de exames", v.resultado_exames],
    ["Conduta", v.conduta],
  ];

  const blocos = visitas
    .map(
      (v) => `
      <div class="impressao-quebra">
        ${montarFichaAtendimentoHtml(paciente, medico, formatarDataHoraAtendimento(v.data), v.tipo_atendimento, camposDe(v))}
      </div>
    `
    )
    .join("");

  const html = `
    ${montarCapaTransferencia(paciente, medico, visitas, agora)}
    ${blocos}
    <div class="impressao-rodape">Documento gerado em ${agora}</div>
    ${montarRodapeAssinaturaImpressao(medico)}
  `;

  const areaImpressao = document.getElementById("area-impressao");
  areaImpressao.innerHTML = html;
  areaImpressao.classList.add("com-rodape-fixo");
  window.print();
}

document.getElementById("btn-imprimir-atendimento").addEventListener("click", async () => {
  const paciente = pacienteAtendimentoAtual;
  if (!paciente) return;

  const medico = await invoke("get_medico_config");
  const dados = coletarDadosFormAtendimento();
  const dataLabel = atendimentoDataAtual ? formatarDataHoraAtendimento(atendimentoDataAtual) : "Rascunho (ainda não salvo)";
  const agora = new Date().toLocaleString("pt-BR");

  const campos = [
    ["Consulta", dados.primeiraConsulta],
    ["Sinais vitais", montarResumoSinaisVitais({
      fc: dados.frequenciaCardiaca,
      paSistolica: dados.pressaoSistolica,
      paDiastolica: dados.pressaoDiastolica,
      fr: dados.frequenciaRespiratoria,
      temp: dados.temperatura,
      obs: dados.sinaisVitaisObs,
    })],
    ["HPP (História Patológica Pregressa)", dados.hpp],
    ["História familiar", dados.historiaFamiliar],
    ["Alergias", dados.alergias],
    ["Medicação em uso", dados.medicacaoUso],
    ["Exame físico", dados.exameFisico],
    ["CID (diagnóstico padronizado)", dados.cid],
    ["Diagnóstico atual", dados.diagnosticoAtual],
    ["Diagnóstico prévio", dados.diagnosticoPrevio],
    ["Resultado de exames", dados.resultadoExames],
    ["Conduta", dados.conduta],
  ];

  const html = `
    ${montarFichaAtendimentoHtml(paciente, medico, dataLabel, dados.tipoAtendimento, campos)}
    <div class="impressao-rodape">Documento gerado em ${agora}</div>
    ${montarRodapeAssinaturaImpressao(medico)}
  `;

  const areaImpressao = document.getElementById("area-impressao");
  areaImpressao.innerHTML = html;
  areaImpressao.classList.add("com-rodape-fixo");
  window.print();
});

// ---------- Modal: histórico rápido (consulta sem sair do atendimento) ----------

const modalOverlay = document.getElementById("modal-historico");
const modalListaView = document.getElementById("modal-lista-view");
const modalDetalheView = document.getElementById("modal-detalhe-view");
const modalBtnVoltarLista = document.getElementById("modal-btn-voltar-lista");

document.getElementById("btn-abrir-historico").addEventListener("click", async () => {
  if (!pacienteAtualId) return;

  const atendimentos = await invoke("list_visits", { pacienteId: pacienteAtualId });
  const container = document.getElementById("modal-lista-atendimentos");
  const vazio = document.getElementById("modal-lista-vazia");
  container.innerHTML = "";

  if (atendimentos.length === 0) {
    vazio.classList.remove("oculto");
  } else {
    vazio.classList.add("oculto");
    for (const a of atendimentos) {
      const div = document.createElement("div");
      div.className = "item-atendimento";
      div.innerHTML = `
        <div class="data">${formatarDataHoraAtendimento(a.data)} ${tagTipoAtendimento(a.tipo_atendimento)}</div>
        <div class="resumo">${escapeHtml(a.resumo || "(sem diagnóstico registrado)")}</div>
      `;
      div.addEventListener("click", () => mostrarDetalheNoModal(a.id));
      container.appendChild(div);
    }
  }

  document.getElementById("modal-titulo").textContent = "Histórico de atendimentos";
  modalBtnVoltarLista.classList.add("oculto");
  modalListaView.classList.remove("oculto");
  modalDetalheView.classList.add("oculto");
  modalOverlay.classList.remove("oculto");
});

async function mostrarDetalheNoModal(visitaId) {
  const a = await invoke("get_visit", { id: visitaId });

  document.getElementById("modal-d-primeira-consulta").textContent = a.primeira_consulta || "—";
  document.getElementById("modal-d-sinais-vitais").textContent = montarResumoSinaisVitais({
    fc: a.frequencia_cardiaca,
    paSistolica: a.pressao_sistolica,
    paDiastolica: a.pressao_diastolica,
    fr: a.frequencia_respiratoria,
    temp: a.temperatura,
    obs: a.sinais_vitais_obs,
  }) || "—";
  document.getElementById("modal-d-hpp").textContent = a.hpp || "—";
  document.getElementById("modal-d-historia-familiar").textContent = a.historia_familiar || "—";
  document.getElementById("modal-d-alergias").textContent = a.alergias || "—";
  document.getElementById("modal-d-medicacao").textContent = a.medicacao_uso || "—";
  document.getElementById("modal-d-exame").textContent = a.exame_fisico || "—";
  document.getElementById("modal-d-cid").textContent = a.cid || "—";
  document.getElementById("modal-d-diagnostico-atual").textContent = a.diagnostico_atual || "—";
  document.getElementById("modal-d-diagnostico-previo").textContent = a.diagnostico_previo || "—";
  document.getElementById("modal-d-resultado-exames").textContent = a.resultado_exames || "—";
  document.getElementById("modal-d-conduta").textContent = a.conduta || "—";

  document.getElementById("modal-titulo").textContent = `Atendimento de ${formatarDataHoraAtendimento(a.data)}`;
  modalBtnVoltarLista.classList.remove("oculto");
  modalListaView.classList.add("oculto");
  modalDetalheView.classList.remove("oculto");
}

modalBtnVoltarLista.addEventListener("click", () => {
  document.getElementById("btn-abrir-historico").click();
});

document.getElementById("modal-fechar").addEventListener("click", () => {
  modalOverlay.classList.add("oculto");
});

modalOverlay.addEventListener("click", (e) => {
  if (e.target === modalOverlay) modalOverlay.classList.add("oculto");
});

// ---------- Menu lateral ----------

async function podeSairDoAtendimento() {
  const telaVisivel = Object.entries(telas).find(([, el]) => !el.classList.contains("oculto"))[0];
  if (telaVisivel === "atendimento" && formAtendimentoSujo) {
    return await confirmarAcao("Você tem alterações não salvas neste atendimento. Deseja realmente sair sem salvar?");
  }
  return true;
}

document.getElementById("nav-home").addEventListener("click", async () => {
  if (!(await podeSairDoAtendimento())) return;
  formAtendimentoSujo = false;
  pacienteAtualId = null;
  mostrarTela("inicio");
  carregarInicio();
});

document.getElementById("nav-inicio").addEventListener("click", async () => {
  if (!(await podeSairDoAtendimento())) return;
  formAtendimentoSujo = false;
  pacienteAtualId = null;
  mostrarTela("recentes");
  carregarRecentes();
});

document.getElementById("nav-pacientes").addEventListener("click", async () => {
  if (!(await podeSairDoAtendimento())) return;
  formAtendimentoSujo = false;
  pacienteAtualId = null;
  campoBusca.value = "";
  buscaDropdown.classList.add("oculto");
  setBreadcrumb([{ text: "Pacientes" }]);
  mostrarTela("lista");
  carregarPacientes();
});

document.getElementById("nav-relatorios").addEventListener("click", async () => {
  if (!(await podeSairDoAtendimento())) return;
  formAtendimentoSujo = false;
  pacienteAtualId = null;
  setBreadcrumb([{ text: "Relatórios" }]);
  mostrarTela("relatorios");
});

document.getElementById("nav-novo-paciente").addEventListener("click", async () => {
  if (!(await podeSairDoAtendimento())) return;
  formAtendimentoSujo = false;
  abrirCadastro(null);
});

document.getElementById("nav-medico-config").addEventListener("click", async () => {
  if (!(await podeSairDoAtendimento())) return;
  formAtendimentoSujo = false;
  const config = await invoke("get_medico_config");
  document.getElementById("m-nome").value = config ? config.nome : "";
  document.getElementById("m-crm").value = config ? config.crm : "";
  document.getElementById("m-rqe").value = config ? config.rqe : "";
  document.getElementById("m-especialidade").value = config ? config.especialidade : "";
  document.getElementById("m-endereco").value = config ? config.endereco : "";
  document.getElementById("m-telefone").value = config ? config.telefone : "";
  document.getElementById("m-celular").value = config ? config.celular : "";
  document.getElementById("m-cidade").value = config && config.cidade ? config.cidade : "Nova Friburgo";
  document.getElementById("m-uf").value = config && config.uf ? config.uf : "RJ";
  setBreadcrumb([{ text: "Dados do médico" }]);
  mostrarTela("medicoConfig");
});

document.getElementById("form-medico-config").addEventListener("submit", async (e) => {
  e.preventDefault();
  await invoke("salvar_medico_config", {
    nome: document.getElementById("m-nome").value.trim(),
    crm: document.getElementById("m-crm").value.trim(),
    rqe: document.getElementById("m-rqe").value.trim(),
    especialidade: document.getElementById("m-especialidade").value.trim(),
    endereco: document.getElementById("m-endereco").value.trim(),
    telefone: document.getElementById("m-telefone").value.trim(),
    celular: document.getElementById("m-celular").value.trim(),
    cidade: document.getElementById("m-cidade").value.trim(),
    uf: document.getElementById("m-uf").value.trim().toUpperCase(),
  });
  mostrarToast("Dados do médico salvos");
  carregarSaudacao();
});

// ---------- Documentos (receituário, atestado, laudo, declaração) ----------

const MESES_EXTENSO = [
  "janeiro", "fevereiro", "março", "abril", "maio", "junho",
  "julho", "agosto", "setembro", "outubro", "novembro", "dezembro",
];

function dataCurta(data) {
  const d = data || new Date();
  const dd = String(d.getDate()).padStart(2, "0");
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  return `${dd}/${mm}/${d.getFullYear()}`;
}

function dataPorExtenso(data) {
  const d = data || new Date();
  return `${d.getDate()} de ${MESES_EXTENSO[d.getMonth()]} de ${d.getFullYear()}`;
}

function definirOrientacaoImpressao(paisagem) {
  let estilo = document.getElementById("estilo-orientacao-impressao");
  if (!estilo) {
    estilo = document.createElement("style");
    estilo.id = "estilo-orientacao-impressao";
    document.head.appendChild(estilo);
  }
  estilo.textContent = paisagem ? "@page { size: landscape; }" : "";
}

function localDocumento(medico) {
  const cidade = medico && medico.cidade ? medico.cidade : "Nova Friburgo";
  const uf = medico && medico.uf ? medico.uf : "RJ";
  return `${cidade} - ${uf}`;
}

function emitenteCompleto(medico) {
  return !!(medico && medico.nome && medico.crm && medico.endereco);
}

// Receituário de Controle Especial (modelo da Portaria SVS/MS 344/98): via = 1 (farmácia) ou 2 (paciente)
function montarViaEspecial(paciente, medico, corpo, via) {
  const m = medico || {};
  const cidadeUf = [m.cidade, m.uf].filter(Boolean).join(" / ");
  const corpoHtml = corpo && corpo.trim()
    ? escapeHtml(corpo)
    : '<span class="doc-preview-vazio">A prescrição aparece aqui conforme você digita…</span>';
  const campo = (rotulo, valor) =>
    `<div class="rce-linha"><span class="rce-rotulo">${rotulo}</span><span class="rce-valor">${valor ? escapeHtml(valor) : ""}</span></div>`;
  const viaTexto = (ativa, texto) =>
    `<div class="rce-via${ativa ? " ativa" : ""}"><span class="rce-marca"></span>${texto}</div>`;

  const registro = [m.crm, m.rqe].filter(Boolean).join(" - ");
  const enderecoLinha = [m.endereco, cidadeUf].filter(Boolean).join(" - ");
  const contatos = [];
  if (m.telefone) contatos.push(`Tel.: ${escapeHtml(m.telefone)}`);
  if (m.celular) contatos.push(`Cel.: ${escapeHtml(m.celular)}`);

  return `
    <div class="rce">
      <div class="rce-titulo">RECEITUÁRIO DE CONTROLE ESPECIAL</div>

      <div class="rce-topo">
        <div class="rce-caixa rce-emitente">
          <div class="rce-caixa-titulo">IDENTIFICAÇÃO DO EMITENTE</div>
          <div class="rce-caixa-corpo rce-emitente-corpo">
            <div class="rce-emitente-nome">${escapeHtml(m.nome || "")}</div>
            ${registro ? `<div class="rce-emitente-registro">${escapeHtml(registro)}</div>` : ""}
            ${enderecoLinha ? `<div class="rce-emitente-endereco">${escapeHtml(enderecoLinha)}</div>` : ""}
            ${contatos.length ? `<div class="rce-emitente-contato">${contatos.join("&nbsp;&nbsp;&nbsp;/&nbsp;")}</div>` : ""}
          </div>
        </div>
        <div class="rce-vias">
          ${viaTexto(via === 1, "1ª VIA – FARMÁCIA")}
          ${viaTexto(via === 2, "2ª VIA – PACIENTE")}
        </div>
      </div>

      ${campo("Paciente:", paciente ? paciente.nome : "")}
      ${campo("Endereço:", paciente ? enderecoResumido(paciente) : "")}

      <div class="rce-rotulo rce-rotulo-prescricao">Prescrição:</div>
      <div class="rce-prescricao">${corpoHtml}</div>

      <div class="rce-finalizacao">
        <div class="rce-data-emitente">
          <div class="rce-valor-acima">${escapeHtml(dataCurta())}</div>
          <div class="rce-linha-curta"></div>
          <div class="rce-rotulo-abaixo">Data</div>
        </div>
        <div class="rce-assinatura-emitente">
          <div class="rce-linha-curta"></div>
          <div class="rce-rotulo-abaixo">Assinatura e Carimbo do Emitente</div>
        </div>
      </div>

      <div class="rce-rodape">
        <div class="rce-caixa">
          <div class="rce-caixa-titulo">IDENTIFICAÇÃO DO COMPRADOR</div>
          <div class="rce-caixa-corpo">
            ${campo("Nome:", "")}
            ${campo("Ident.:", "")}
            ${campo("Órg. Emissor:", "")}
            ${campo("End.:", "")}
            ${campo("Cidade / UF:", "")}
            ${campo("Telefone:", "")}
          </div>
        </div>
        <div class="rce-caixa">
          <div class="rce-caixa-titulo">IDENTIFICAÇÃO DO FORNECEDOR</div>
          <div class="rce-caixa-corpo rce-fornecedor">
            <div class="rce-espaco"></div>
            <div class="rce-linha-assinatura-farm">Assinatura do Farmacêutico</div>
            <div class="rce-data-farm">DATA: ____ / ____ / ____</div>
          </div>
        </div>
      </div>
    </div>
  `;
}

function montarViaDocumento(tipo, paciente, medico, corpo, via) {
  if (tipo === "Receituário Especial") return montarViaEspecial(paciente, medico, corpo, via || 1);
  const idade = paciente ? calcularIdade(paciente.data_nascimento) : null;
  const nascimentoTexto = paciente && paciente.data_nascimento ? formatarData(paciente.data_nascimento) : "—";
  const corpoHtml = corpo && corpo.trim()
    ? escapeHtml(corpo)
    : '<span class="doc-preview-vazio">O conteúdo aparece aqui conforme você digita…</span>';

  return `
    <div class="doc2">
      ${montarCabecalhoDoc2(medico)}

      <div class="doc2-titulo">${escapeHtml(tipo.toUpperCase())}</div>

      <div class="impressao-doc-paciente">
        <strong>Paciente:</strong> ${paciente ? escapeHtml(paciente.nome) : "—"}${idade !== null ? ` (${idade} anos)` : ""}<br>
        <strong>Data de nascimento:</strong> ${nascimentoTexto}<br>
        <strong>CPF:</strong> ${paciente && paciente.documento ? escapeHtml(paciente.documento) : "—"}<br>
        <strong>Endereço:</strong> ${paciente && enderecoCompleto(paciente) ? escapeHtml(enderecoCompleto(paciente)) : "—"}
      </div>

      <div class="doc2-corpo">${corpoHtml}</div>

      ${montarRodapeDoc2(medico)}
    </div>
  `;
}

let pacienteDocumentoAtual = null;
let medicoDocumentoAtual = null;
let modelosDocumentoAtual = [];
let documentoEmEdicaoId = null;

// Tipos que usam o timbre simples (nome + MÉDICO + CRM), com frase fixa e sem o bloco de dados do paciente
const TIPOS_TIMBRE_SIMPLES = ["Atestado Médico", "Atestado de Saúde", "Declaração de Comparecimento", "Declaração Fralda", "Modelo em Branco"];
// Tipos cuja frase é 100% fixa (sem caixa de "Conteúdo" livre)
const TIPOS_SEM_CONTEUDO_LIVRE = ["Atestado Médico", "Atestado de Saúde", "Declaração de Comparecimento", "Declaração Fralda"];

function nomePacienteOuLinha(paciente) {
  return paciente && paciente.nome ? escapeHtml(paciente.nome) : "_______________________________";
}

function montarCorpoTipoFixo(tipo, paciente, extra) {
  const nome = `<strong>${nomePacienteOuLinha(paciente)}</strong>`;
  if (tipo === "Atestado Médico") {
    const dias = extra.dias && extra.dias.trim() ? escapeHtml(extra.dias.trim()) : "_____";
    return `Atesto para os devidos fins que ${nome} necessita de afastamento de suas atividades profissionais/escolares por <strong>${dias}</strong> dias.`;
  }
  if (tipo === "Atestado de Saúde") {
    return `Atesto para os devidos fins que ${nome} encontra-se apto(a) para praticar exercícios físicos.`;
  }
  if (tipo === "Declaração de Comparecimento") {
    const horario = extra.horario && extra.horario.trim() ? escapeHtml(extra.horario.trim()) : "_______________";
    return `Declaro que ${nome} compareceu para consulta médica no horário de <strong>${horario}</strong>.`;
  }
  if (tipo === "Declaração Fralda") {
    return `Declaro que o paciente ${nome} necessita do uso de fraldas descartáveis de uso contínuo.`;
  }
  return "";
}

function montarCabecalhoDoc2(medico) {
  const m = medico || {};
  const registro = [m.crm, m.rqe].filter(Boolean).join(" - ");
  return `
    <div class="doc2-cabecalho">
      <div class="doc2-nome-medico">${escapeHtml(m.nome || "")}</div>
      <div class="doc2-papel">MÉDICO</div>
      ${registro ? `<div class="doc2-crm">${escapeHtml(registro)}</div>` : ""}
    </div>
    <hr class="doc2-regua">
  `;
}

function montarRodapeDoc2(medico) {
  const m = medico || {};
  const cidade = m.cidade || "Nova Friburgo";
  const contatos = [];
  if (m.telefone) contatos.push(`Tel.: ${escapeHtml(m.telefone)}`);
  if (m.celular) contatos.push(`Cel.: ${escapeHtml(m.celular)}`);

  return `
    <div class="doc2-data">${escapeHtml(cidade)}, ${dataPorExtenso()}</div>

    <div class="doc2-assinatura">
      <div class="doc2-linha-assinatura"></div>
      <div class="doc2-nome-assinatura">${escapeHtml((m.nome || "").toUpperCase())}</div>
    </div>

    <hr class="doc2-regua-rodape">
    <div class="doc2-rodape">
      <div><strong>${escapeHtml(cidade)}</strong>${m.endereco ? ` - ${escapeHtml(m.endereco)}` : ""}</div>
      ${contatos.length ? `<div>${contatos.join("&nbsp;&nbsp;&nbsp;/&nbsp;")}</div>` : ""}
    </div>
  `;
}

function montarDocumentoTimbreSimples(tipo, paciente, medico, extra) {
  const miolo = tipo === "Modelo em Branco"
    ? (extra.corpo && extra.corpo.trim()
        ? `<span class="doc2-continuacao">${escapeHtml(extra.corpo)}</span>`
        : '<span class="doc-preview-vazio">O conteúdo aparece aqui conforme você digita…</span>')
    : montarCorpoTipoFixo(tipo, paciente, extra);

  return `
    <div class="doc2">
      ${montarCabecalhoDoc2(medico)}

      ${tipo !== "Modelo em Branco" ? `<div class="doc2-titulo">${escapeHtml(tipo.toUpperCase())}</div>` : ""}

      <div class="doc2-corpo">${miolo}</div>

      ${montarRodapeDoc2(medico)}
    </div>
  `;
}

function coletarExtraDocumento() {
  return {
    dias: document.getElementById("doc-dias").value,
    horario: document.getElementById("doc-horario").value,
    corpo: document.getElementById("doc-corpo").value,
  };
}

function montarConteudoDocumento(tipo, paciente, medico, extra) {
  if (TIPOS_TIMBRE_SIMPLES.includes(tipo)) {
    return montarDocumentoTimbreSimples(tipo, paciente, medico, extra);
  }
  return montarViaDocumento(tipo, paciente, medico, extra.corpo);
}

function atualizarCamposPorTipo() {
  const tipo = document.getElementById("doc-tipo").value;

  document.getElementById("doc-campo-dias").classList.toggle("oculto", tipo !== "Atestado Médico");
  document.getElementById("doc-campo-horario").classList.toggle("oculto", tipo !== "Declaração de Comparecimento");

  const semConteudoLivre = TIPOS_SEM_CONTEUDO_LIVRE.includes(tipo);
  document.getElementById("doc-campo-conteudo").classList.toggle("oculto", semConteudoLivre);
  document.getElementById("doc-campo-buscar-modelo").classList.toggle("oculto", semConteudoLivre);
  document.getElementById("doc-acoes-modelo").classList.toggle("oculto", semConteudoLivre);

  document.getElementById("doc-rotulo-conteudo").textContent = "Conteúdo";

  document
    .getElementById("doc-aviso-emitente")
    .classList.toggle("oculto", tipo !== "Receituário Especial" || emitenteCompleto(medicoDocumentoAtual));
}

function atualizarPreviewDocumento() {
  atualizarCamposPorTipo();
  const tipo = document.getElementById("doc-tipo").value;
  const extra = coletarExtraDocumento();
  document.getElementById("doc-preview-area").innerHTML = montarConteudoDocumento(
    tipo,
    pacienteDocumentoAtual,
    medicoDocumentoAtual,
    extra
  );
}

async function carregarModelosParaTipo(tipo) {
  modelosDocumentoAtual = await invoke("list_modelos_documento", { tipoDocumento: tipo });
  document.getElementById("lista-modelos-documento").innerHTML = modelosDocumentoAtual
    .map((m) => `<option value="${escapeHtml(m.nome)}"></option>`)
    .join("");
}

async function abrirModalDocumento(paciente, documento) {
  if (!paciente) return;
  pacienteDocumentoAtual = paciente;
  medicoDocumentoAtual = await invoke("get_medico_config");
  documentoEmEdicaoId = documento ? documento.id : null;
  const tipoInicial = documento ? documento.tipo : "Receituário Simples";

  document.getElementById("modal-documento-titulo").textContent = documento ? "Editar documento" : "Novo documento";
  document.getElementById("doc-tipo").value = tipoInicial;
  document.getElementById("doc-dias").value = documento && tipoInicial === "Atestado Médico" ? documento.conteudo : "";
  document.getElementById("doc-horario").value = documento && tipoInicial === "Declaração de Comparecimento" ? documento.conteudo : "";
  document.getElementById("doc-corpo").value =
    documento && !TIPOS_SEM_CONTEUDO_LIVRE.includes(tipoInicial) ? documento.conteudo : "";
  document.getElementById("doc-buscar-modelo").value = "";
  document.getElementById("doc-salvar-modelo-linha").classList.add("oculto");
  document.getElementById("doc-nome-modelo").value = "";

  await carregarModelosParaTipo(tipoInicial);

  document.getElementById("modal-documento").classList.remove("oculto");
  atualizarPreviewDocumento();
  reajustarTodasAsCaixas("#modal-documento textarea");
}

function fecharModalDocumento() {
  document.getElementById("modal-documento").classList.add("oculto");
}

document.getElementById("btn-novo-documento-atendimento").addEventListener("click", () => {
  abrirModalDocumento(pacienteAtendimentoAtual);
});

document.getElementById("modal-documento-fechar").addEventListener("click", fecharModalDocumento);
document.getElementById("modal-documento-cancelar").addEventListener("click", fecharModalDocumento);

document.getElementById("doc-tipo").addEventListener("change", async () => {
  const tipo = document.getElementById("doc-tipo").value;
  document.getElementById("doc-buscar-modelo").value = "";
  document.getElementById("doc-dias").value = "";
  document.getElementById("doc-horario").value = "";
  document.getElementById("doc-corpo").value = "";
  await carregarModelosParaTipo(tipo);
  atualizarPreviewDocumento();
  reajustarTodasAsCaixas("#modal-documento textarea");
});

document.getElementById("doc-corpo").addEventListener("input", atualizarPreviewDocumento);
document.getElementById("doc-dias").addEventListener("input", atualizarPreviewDocumento);
document.getElementById("doc-horario").addEventListener("input", atualizarPreviewDocumento);

document.getElementById("doc-buscar-modelo").addEventListener("input", (e) => {
  const encontrado = modelosDocumentoAtual.find((m) => m.nome === e.target.value);
  if (!encontrado) return;
  document.getElementById("doc-corpo").value = encontrado.conteudo;
  e.target.value = "";
  reajustarTodasAsCaixas("#modal-documento textarea");
  atualizarPreviewDocumento();
});

document.getElementById("btn-limpar-documento").addEventListener("click", () => {
  document.getElementById("doc-corpo").value = "";
  document.getElementById("doc-buscar-modelo").value = "";
  reajustarTodasAsCaixas("#modal-documento textarea");
  atualizarPreviewDocumento();
});

document.getElementById("btn-salvar-modelo").addEventListener("click", () => {
  if (!document.getElementById("doc-corpo").value.trim()) {
    mostrarToast("Escreva algum conteúdo antes de salvar como modelo");
    return;
  }
  document.getElementById("doc-salvar-modelo-linha").classList.remove("oculto");
  document.getElementById("doc-nome-modelo").focus();
});

document.getElementById("doc-cancelar-salvar-modelo").addEventListener("click", () => {
  document.getElementById("doc-salvar-modelo-linha").classList.add("oculto");
  document.getElementById("doc-nome-modelo").value = "";
});

document.getElementById("doc-confirmar-salvar-modelo").addEventListener("click", async () => {
  const nome = document.getElementById("doc-nome-modelo").value.trim();
  const conteudo = document.getElementById("doc-corpo").value.trim();

  if (!nome || !conteudo) {
    mostrarToast("Preencha o nome do modelo");
    return;
  }

  const tipo = document.getElementById("doc-tipo").value;
  await invoke("add_modelo_documento", { tipoDocumento: tipo, nome, conteudo });

  document.getElementById("doc-salvar-modelo-linha").classList.add("oculto");
  document.getElementById("doc-nome-modelo").value = "";
  await carregarModelosParaTipo(tipo);
  mostrarToast("Modelo salvo");
});

document.getElementById("modal-documento-gerar").addEventListener("click", async () => {
  const paciente = pacienteDocumentoAtual;
  if (!paciente) return;

  const tipo = document.getElementById("doc-tipo").value;
  const extra = coletarExtraDocumento();

  if (tipo === "Atestado Médico" && !extra.dias.trim()) {
    mostrarToast("Preencha os dias de afastamento");
    return;
  }
  if (tipo === "Declaração de Comparecimento" && !extra.horario.trim()) {
    mostrarToast("Preencha o horário");
    return;
  }
  if (!TIPOS_SEM_CONTEUDO_LIVRE.includes(tipo) && tipo !== "Atestado de Saúde" && !extra.corpo.trim()) {
    mostrarToast("Escreva o conteúdo do documento antes de gerar");
    return;
  }

  const ehEspecial = tipo === "Receituário Especial";
  if (ehEspecial && !emitenteCompleto(medicoDocumentoAtual)) {
    mostrarToast("Preencha nome, CRM e endereço em Dados do médico para gerar o receituário especial");
    return;
  }

  // O que salvar no histórico depende do tipo: pros de frase fixa, só a parte variável.
  let conteudoParaSalvar = extra.corpo.trim();
  if (tipo === "Atestado Médico") conteudoParaSalvar = extra.dias.trim();
  else if (tipo === "Atestado de Saúde") conteudoParaSalvar = "";
  else if (tipo === "Declaração de Comparecimento") conteudoParaSalvar = extra.horario.trim();

  if (documentoEmEdicaoId) {
    await invoke("update_documento", { id: documentoEmEdicaoId, tipo, conteudo: conteudoParaSalvar });
  } else {
    await invoke("add_documento", { pacienteId: paciente.id, tipo, conteudo: conteudoParaSalvar });
  }
  if (!telas.ficha.classList.contains("oculto") && pacienteAtualId === paciente.id) {
    await carregarDocumentos(paciente);
    selecionarAbaFicha("documentos");
  }

  const html = ehEspecial
    ? `<div class="impressao-duas-vias"><div>${montarViaDocumento(tipo, paciente, medicoDocumentoAtual, extra.corpo, 1)}</div><div>${montarViaDocumento(tipo, paciente, medicoDocumentoAtual, extra.corpo, 2)}</div></div>`
    : montarConteudoDocumento(tipo, paciente, medicoDocumentoAtual, extra);

  const areaImpressao = document.getElementById("area-impressao");
  areaImpressao.innerHTML = html;
  areaImpressao.classList.remove("com-rodape-fixo");
  definirOrientacaoImpressao(ehEspecial);
  fecharModalDocumento();
  window.print();
});

// ---------- Histórico de documentos gerados (na ficha do paciente) ----------

const ICONE_LAPIS = '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M13.5 3.5 16.5 6.5 6.5 16.5 3 17l.5-3.5Z"/></svg>';
const ICONE_LIXEIRA = '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="6" x2="16" y2="6"/><path d="M7 6V4.5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1V6"/><path d="M5.5 6 6.3 16a1 1 0 0 0 1 1h5.4a1 1 0 0 0 1-1L14.5 6"/><line x1="8.5" y1="9" x2="8.5" y2="14"/><line x1="11.5" y1="9" x2="11.5" y2="14"/></svg>';
const ICONE_DISQUETE = '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 3h9l3 3v10a1 1 0 0 1-1 1h-11a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/><path d="M6.5 3v4h6V3"/><rect x="6" y="11" width="8" height="6"/></svg>';

let documentoParaModelo = null;

async function carregarDocumentos(paciente) {
  const container = document.getElementById("lista-documentos");
  const vazio = document.getElementById("documentos-vazio");
  const documentos = await invoke("list_documentos", { pacienteId: paciente.id });

  container.innerHTML = "";
  vazio.classList.toggle("oculto", documentos.length > 0);
  document.getElementById("aba-documentos").textContent = documentos.length
    ? `Documentos emitidos (${documentos.length})`
    : "Documentos emitidos";

  for (const d of documentos) {
    let previa = d.conteudo.replace(/\s+/g, " ").trim();
    if (d.tipo === "Atestado Médico") previa = previa ? `${previa} dia(s) de afastamento` : "";
    else if (d.tipo === "Declaração de Comparecimento") previa = previa ? `Horário: ${previa}` : "";
    else if (d.tipo === "Atestado de Saúde") previa = "Apto(a) para exercícios físicos";
    else if (d.tipo === "Declaração Fralda") previa = "Necessita do uso de fraldas descartáveis";
    const div = document.createElement("div");
    div.className = "item-documento";
    div.innerHTML = `
      <div class="item-documento-info">
        <div class="item-documento-topo">
          <span class="item-documento-tipo">${escapeHtml(d.tipo)}</span>
          <span class="item-documento-data">${formatarDataHoraIso(d.atualizado_em)}</span>
        </div>
        <div class="item-documento-previa">${escapeHtml(previa)}</div>
      </div>
      <div class="item-documento-acoes">
        <button type="button" class="icone-acao" data-acao="editar" data-tooltip="Editar" aria-label="Editar">${ICONE_LAPIS}</button>
        <button type="button" class="icone-acao salvar" data-acao="modelo" data-tooltip="Salvar como modelo" aria-label="Salvar como modelo">${ICONE_DISQUETE}</button>
        <button type="button" class="icone-acao perigo" data-acao="excluir" data-tooltip="Excluir" aria-label="Excluir">${ICONE_LIXEIRA}</button>
      </div>
    `;

    div.querySelector('[data-acao="editar"]').addEventListener("click", () => abrirModalDocumento(paciente, d));

    div.querySelector('[data-acao="modelo"]').addEventListener("click", () => {
      documentoParaModelo = d;
      document.getElementById("salvar-modelo-doc-tipo").textContent = d.tipo;
      document.getElementById("salvar-modelo-doc-nome").value = "";
      document.getElementById("modal-salvar-modelo-doc").classList.remove("oculto");
      document.getElementById("salvar-modelo-doc-nome").focus();
    });

    div.querySelector('[data-acao="excluir"]').addEventListener("click", async () => {
      const confirmar = await confirmarAcao(`Excluir este documento (${d.tipo}) do histórico? Essa ação não pode ser desfeita.`);
      if (!confirmar) return;
      await invoke("delete_documento", { id: d.id });
      mostrarToast("Documento excluído");
      await carregarDocumentos(paciente);
    });

    container.appendChild(div);
  }
}

function fecharModalSalvarModeloDoc() {
  document.getElementById("modal-salvar-modelo-doc").classList.add("oculto");
  documentoParaModelo = null;
}

document.getElementById("salvar-modelo-doc-cancelar").addEventListener("click", fecharModalSalvarModeloDoc);
document.getElementById("salvar-modelo-doc-confirmar").addEventListener("click", async () => {
  const nome = document.getElementById("salvar-modelo-doc-nome").value.trim();
  if (!nome) {
    mostrarToast("Digite um nome para o modelo");
    return;
  }
  if (!documentoParaModelo) return;
  await invoke("add_modelo_documento", {
    tipoDocumento: documentoParaModelo.tipo,
    nome,
    conteudo: documentoParaModelo.conteudo,
  });
  fecharModalSalvarModeloDoc();
  mostrarToast("Modelo salvo");
});

// ---------- Tela inicial: cartões e seletor de paciente ----------

let acaoAoEscolherPaciente = null;
let buscaPacienteTimeout;

async function carregarListaSeletorPaciente() {
  const busca = document.getElementById("escolher-paciente-busca").value.trim();
  const pacientes = await invoke("list_patients", { busca });
  const lista = document.getElementById("escolher-paciente-lista");
  if (!pacientes.length) {
    lista.innerHTML = '<p class="exames-vazio">Nenhum paciente encontrado.</p>';
    return;
  }
  lista.innerHTML = pacientes
    .map((p) => `<button type="button" class="escolher-paciente-item" data-id="${p.id}">${escapeHtml(p.nome)}</button>`)
    .join("");
  lista.querySelectorAll(".escolher-paciente-item").forEach((b) => {
    b.addEventListener("click", () => {
      const acao = acaoAoEscolherPaciente;
      fecharSeletorPaciente();
      if (acao) acao(b.dataset.id);
    });
  });
}

async function abrirSeletorPaciente(titulo, acao) {
  acaoAoEscolherPaciente = acao;
  document.getElementById("escolher-paciente-titulo").textContent = titulo;
  document.getElementById("escolher-paciente-busca").value = "";
  document.getElementById("modal-escolher-paciente").classList.remove("oculto");
  document.getElementById("escolher-paciente-busca").focus();
  await carregarListaSeletorPaciente();
}

function fecharSeletorPaciente() {
  document.getElementById("modal-escolher-paciente").classList.add("oculto");
  acaoAoEscolherPaciente = null;
}

document.getElementById("escolher-paciente-fechar").addEventListener("click", fecharSeletorPaciente);
document.getElementById("escolher-paciente-busca").addEventListener("input", () => {
  clearTimeout(buscaPacienteTimeout);
  buscaPacienteTimeout = setTimeout(carregarListaSeletorPaciente, 150);
});

document.getElementById("inicio-listar-pacientes").addEventListener("click", () => {
  document.getElementById("nav-pacientes").click();
});
document.getElementById("inicio-novo-paciente").addEventListener("click", () => {
  document.getElementById("nav-novo-paciente").click();
});
document.getElementById("inicio-atendimentos-recentes").addEventListener("click", () => {
  document.getElementById("nav-inicio").click();
});
document.getElementById("inicio-novo-atendimento").addEventListener("click", () => {
  abrirSeletorPaciente("Novo atendimento — escolha o paciente", (id) => abrirNovoAtendimento(id));
});
document.getElementById("inicio-novo-documento").addEventListener("click", () => {
  abrirSeletorPaciente("Novo documento — escolha o paciente", async (id) => {
    const paciente = await invoke("get_patient", { id });
    abrirModalDocumento(paciente);
  });
});

document.getElementById("inicio-dados-medico").addEventListener("click", () => {
  document.getElementById("nav-medico-config").click();
});
document.getElementById("inicio-backup").addEventListener("click", () => {
  document.getElementById("btn-backup").click();
});

// ---------- Botão voltar da barra superior ----------

btnVoltar.addEventListener("click", async () => {
  const telaVisivel = Object.entries(telas).find(([, el]) => !el.classList.contains("oculto"))[0];

  if (telaVisivel === "atendimento") {
    if (formAtendimentoSujo) {
      const sair = await confirmarAcao("Você tem alterações não salvas neste atendimento. Deseja realmente sair sem salvar?");
      if (!sair) return;
    }
    formAtendimentoSujo = false;
    abrirFicha(pacienteAtualId);
  } else if (telaVisivel === "ficha") {
    pacienteAtualId = null;
    setBreadcrumb([{ text: "Pacientes" }]);
    mostrarTela("lista");
    carregarPacientes();
  } else if (telaVisivel === "cadastro") {
    voltarDoCadastro();
  } else if (telaVisivel === "medicoConfig" || telaVisivel === "recentes" || telaVisivel === "lista" || telaVisivel === "relatorios") {
    pacienteAtualId = null;
    mostrarTela("inicio");
    carregarInicio();
  }
});

// ---------- Menu Configurações (cascata, na sidebar) ----------

document.getElementById("config-toggle").addEventListener("click", () => {
  const aberto = document.getElementById("config-submenu").classList.toggle("aberto");
  document.getElementById("config-seta").classList.toggle("aberta", aberto);
  document.getElementById("config-toggle").setAttribute("aria-expanded", String(aberto));
});

document.getElementById("atualizacao-backup-toggle").addEventListener("click", () => {
  const aberto = document.getElementById("atualizacao-backup-submenu").classList.toggle("aberto");
  document.getElementById("atualizacao-backup-seta").classList.toggle("aberta", aberto);
  document.getElementById("atualizacao-backup-toggle").setAttribute("aria-expanded", String(aberto));
});

document.getElementById("btn-logout").addEventListener("click", async () => {
  if (!(await podeSairDoAtendimento())) return;
  formAtendimentoSujo = false;
  document.getElementById("app-layout").classList.add("oculto");
  document.getElementById("portao-auth").classList.remove("oculto");
  document.getElementById("login-senha").value = "";
  mostrarEtapaAuth("auth-login");
  document.getElementById("login-senha").focus();
  pacienteAtualId = null;
});

// ---------- Relatórios ----------

function primeiroDiaDoMes() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}
function hojeIso() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

document.getElementById("rel-doc-inicio").value = primeiroDiaDoMes();
document.getElementById("rel-doc-fim").value = hojeIso();
document.getElementById("rel-at-inicio").value = primeiroDiaDoMes();
document.getElementById("rel-at-fim").value = hojeIso();

function renderizarBarras(itens, total) {
  // itens: [{nome, valor}], ordenado do maior pro menor
  const maior = Math.max(1, ...itens.map((i) => i.valor));
  return itens
    .map((i) => {
      const pct = total ? Math.round((i.valor / total) * 100) : 0;
      const largura = Math.round((i.valor / maior) * 100);
      return `
        <div class="rel-barra-item">
          <div class="rel-barra-topo">
            <span class="rel-barra-nome">${escapeHtml(i.nome)}</span>
            <span class="rel-barra-valor">${i.valor} (${pct}%)</span>
          </div>
          <div class="rel-barra-fundo"><div class="rel-barra-cheia" style="width:${largura}%"></div></div>
        </div>`;
    })
    .join("");
}

// ---- Documentos emitidos por período ----
async function gerarRelatorioDocumentos() {
  const inicio = document.getElementById("rel-doc-inicio").value;
  const fim = document.getElementById("rel-doc-fim").value;
  const container = document.getElementById("rel-documentos-resultado");
  if (!inicio || !fim) {
    container.innerHTML = '<p class="estado-vazio">Escolha as duas datas.</p>';
    return;
  }

  const lista = await invoke("list_documentos_periodo", { inicio, fim });
  if (!lista.length) {
    container.innerHTML = '<p class="estado-vazio">Nenhum documento emitido nesse período.</p>';
    return;
  }

  const porTipo = {};
  lista.forEach((d) => { porTipo[d.tipo] = (porTipo[d.tipo] || 0) + 1; });
  const itens = Object.entries(porTipo).map(([nome, valor]) => ({ nome, valor })).sort((a, b) => b.valor - a.valor);

  const linhas = lista
    .map((d) => `<tr><td>${formatarDataHoraIso(d.data)}</td><td>${escapeHtml(d.paciente_nome)}</td><td>${escapeHtml(d.tipo)}</td></tr>`)
    .join("");

  container.innerHTML = `
    <div class="rel-total">Total: ${lista.length} documento${lista.length === 1 ? "" : "s"}</div>
    ${renderizarBarras(itens, lista.length)}
    <div class="rel-tabela-scroll">
      <table class="rel-tabela">
        <thead><tr><th>Data</th><th>Paciente</th><th>Tipo</th></tr></thead>
        <tbody>${linhas}</tbody>
      </table>
    </div>
  `;
}
document.getElementById("btn-rel-documentos").addEventListener("click", gerarRelatorioDocumentos);

// ---- Atendimentos por período ----
async function gerarRelatorioAtendimentos() {
  const inicio = document.getElementById("rel-at-inicio").value;
  const fim = document.getElementById("rel-at-fim").value;
  const container = document.getElementById("rel-atendimentos-resultado");
  if (!inicio || !fim) {
    container.innerHTML = '<p class="estado-vazio">Escolha as duas datas.</p>';
    return;
  }

  const lista = await invoke("list_atendimentos_periodo", { inicio, fim });
  if (!lista.length) {
    container.innerHTML = '<p class="estado-vazio">Nenhum atendimento nesse período.</p>';
    return;
  }

  const porMes = {};
  lista.forEach((a) => {
    const mes = (a.data || "").slice(0, 7); // "YYYY-MM"
    porMes[mes] = (porMes[mes] || 0) + 1;
  });
  const nomesMeses = MESES_EXTENSO;
  const itens = Object.entries(porMes)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([mes, valor]) => {
      const [ano, m] = mes.split("-");
      const nome = m ? `${nomesMeses[parseInt(m, 10) - 1]} de ${ano}` : mes;
      return { nome, valor };
    });

  container.innerHTML = `
    <div class="rel-total">Total: ${lista.length} atendimento${lista.length === 1 ? "" : "s"}</div>
    ${renderizarBarras(itens, lista.length)}
  `;
}
document.getElementById("btn-rel-atendimentos").addEventListener("click", gerarRelatorioAtendimentos);

// ---- Pacientes por sexo ----
async function gerarRelatorioSexo() {
  const container = document.getElementById("rel-sexo-resultado");
  const pacientes = await invoke("list_pacientes_relatorio");
  if (!pacientes.length) {
    container.innerHTML = '<p class="estado-vazio">Nenhum paciente cadastrado ainda.</p>';
    return;
  }
  const contagem = { Masculino: 0, Feminino: 0, "Não informado": 0 };
  pacientes.forEach((p) => {
    const chave = p.sexo === "Masculino" || p.sexo === "Feminino" ? p.sexo : "Não informado";
    contagem[chave]++;
  });
  const itens = Object.entries(contagem).map(([nome, valor]) => ({ nome, valor }));
  container.innerHTML = `
    <div class="rel-total">Total: ${pacientes.length} paciente${pacientes.length === 1 ? "" : "s"}</div>
    ${renderizarBarras(itens, pacientes.length)}
  `;
}

// ---- Pacientes por localidade (bairro) ----
async function gerarRelatorioBairro() {
  const resumo = document.getElementById("rel-bairro-resumo");
  const filtro = document.getElementById("rel-bairro-filtro");
  const pacientes = await invoke("list_pacientes_relatorio");
  if (!pacientes.length) {
    resumo.innerHTML = '<p class="estado-vazio">Nenhum paciente cadastrado ainda.</p>';
    return;
  }

  const porBairro = {};
  pacientes.forEach((p) => {
    const chave = p.bairro && p.bairro.trim() ? p.bairro.trim() : "Não informado";
    porBairro[chave] = (porBairro[chave] || 0) + 1;
  });
  const itens = Object.entries(porBairro).map(([nome, valor]) => ({ nome, valor })).sort((a, b) => b.valor - a.valor);

  resumo.innerHTML = `
    <div class="rel-total">Total: ${pacientes.length} paciente${pacientes.length === 1 ? "" : "s"} · ${itens.length} bairro${itens.length === 1 ? "" : "s"}</div>
    ${renderizarBarras(itens, pacientes.length)}
  `;

  const bairrosOrdenados = itens.map((i) => i.nome).filter((n) => n !== "Não informado").sort((a, b) => a.localeCompare(b, "pt-BR"));
  filtro.innerHTML =
    '<option value="">Selecione…</option>' +
    bairrosOrdenados.map((b) => `<option value="${escapeHtml(b)}">${escapeHtml(b)}</option>`).join("");

  filtro.onchange = () => {
    const bairroEscolhido = filtro.value;
    const listaEl = document.getElementById("rel-bairro-lista");
    if (!bairroEscolhido) {
      listaEl.innerHTML = "";
      return;
    }
    const doBairro = pacientes.filter((p) => (p.bairro || "").trim() === bairroEscolhido);
    const linhas = doBairro
      .map((p) => `<tr><td>${escapeHtml(p.nome)}</td><td>${p.telefone ? escapeHtml(p.telefone) : "—"}</td></tr>`)
      .join("");
    listaEl.innerHTML = `
      <div class="rel-total">${doBairro.length} paciente${doBairro.length === 1 ? "" : "s"} em ${escapeHtml(bairroEscolhido)}</div>
      <div class="rel-tabela-scroll">
        <table class="rel-tabela"><thead><tr><th>Nome</th><th>Telefone</th></tr></thead><tbody>${linhas}</tbody></table>
      </div>
    `;
  };
}

// ---- Pacientes por idade ----
async function gerarRelatorioIdade() {
  const container = document.getElementById("rel-idade-resultado");
  const pacientes = await invoke("list_pacientes_relatorio");
  if (!pacientes.length) {
    container.innerHTML = '<p class="estado-vazio">Nenhum paciente cadastrado ainda.</p>';
    return;
  }
  const faixas = [
    { nome: "0 a 12 anos", min: 0, max: 12, valor: 0 },
    { nome: "13 a 17 anos", min: 13, max: 17, valor: 0 },
    { nome: "18 a 30 anos", min: 18, max: 30, valor: 0 },
    { nome: "31 a 45 anos", min: 31, max: 45, valor: 0 },
    { nome: "46 a 60 anos", min: 46, max: 60, valor: 0 },
    { nome: "61 anos ou mais", min: 61, max: 999, valor: 0 },
  ];
  let semData = 0;
  pacientes.forEach((p) => {
    const idade = calcularIdade(p.data_nascimento);
    if (idade === null || idade === undefined) { semData++; return; }
    const faixa = faixas.find((f) => idade >= f.min && idade <= f.max);
    if (faixa) faixa.valor++;
  });

  const totalComIdade = pacientes.length - semData;
  container.innerHTML = `
    <div class="rel-total">Total: ${pacientes.length} paciente${pacientes.length === 1 ? "" : "s"}${semData ? ` (${semData} sem data de nascimento)` : ""}</div>
    ${renderizarBarras(faixas.map((f) => ({ nome: f.nome, valor: f.valor })), totalComIdade)}
  `;
}

// ---- Abrir/fechar os acordeões de relatório (carrega sob demanda) ----
const relatoriosCarregados = new Set();
document.querySelectorAll(".rel-toggle").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const chave = btn.dataset.relatorio;
    const corpo = document.querySelector(`.rel-corpo[data-relatorio="${chave}"]`);
    const seta = document.querySelector(`.rel-seta[data-relatorio="${chave}"]`);
    const abrir = corpo.classList.contains("oculto");

    document.querySelectorAll(".rel-corpo").forEach((c) => c.classList.add("oculto"));
    document.querySelectorAll(".rel-seta").forEach((s) => s.classList.remove("aberta"));

    if (abrir) {
      corpo.classList.remove("oculto");
      seta.classList.add("aberta");
      if (!relatoriosCarregados.has(chave)) {
        relatoriosCarregados.add(chave);
        if (chave === "sexo") await gerarRelatorioSexo();
        if (chave === "bairro") await gerarRelatorioBairro();
        if (chave === "idade") await gerarRelatorioIdade();
      }
    }
  });
});

// ---------- Portão de autenticação ----------

function mostrarEtapaAuth(etapa) {
  ["auth-setup", "auth-login", "auth-recuperar", "auth-nova-senha"].forEach((id) => {
    document.getElementById(id).classList.toggle("oculto", id !== etapa);
  });
}

function liberarAcessoAoApp() {
  document.getElementById("portao-auth").classList.add("oculto");
  document.getElementById("app-layout").classList.remove("oculto");
  mostrarTela("inicio");
  carregarInicio();
}

async function iniciarPortaoAuth() {
  const configurada = await invoke("auth_configurada");
  if (configurada) {
    mostrarEtapaAuth("auth-login");
    document.getElementById("login-senha").focus();
  } else {
    mostrarEtapaAuth("auth-setup");
  }
}

// Assistente de primeira configuração (3 passos)
function irParaPassoWizard(n) {
  [1, 2, 3].forEach((i) => {
    document.getElementById(`wizard-passo-${i}`).classList.toggle("oculto", i !== n);
  });
  document.querySelectorAll("#wizard-progresso .wizard-bolinha").forEach((el) => {
    const i = Number(el.dataset.passo);
    el.classList.toggle("ativo", i === n);
    el.classList.toggle("feito", i < n);
  });
  const primeiro = document.querySelector(`#wizard-passo-${n} input`);
  if (primeiro) primeiro.focus();
  if (n === 3) {
    const atual = document.documentElement.getAttribute("data-theme") || "light";
    document.querySelectorAll(".wizard-tema").forEach((b) => b.classList.toggle("ativo", b.dataset.tema === atual));
  }
}

document.getElementById("w-telefone").addEventListener("input", (e) => { e.target.value = mascararTelefone(e.target.value); });
document.getElementById("w-celular").addEventListener("input", (e) => { e.target.value = mascararTelefone(e.target.value); });

document.getElementById("wizard-proximo-1").addEventListener("click", () => {
  const erro = document.getElementById("wizard-erro-1");
  if (!document.getElementById("w-nome").value.trim()) {
    erro.textContent = "Informe o nome do médico para continuar.";
    erro.classList.remove("oculto");
    document.getElementById("w-nome").focus();
    return;
  }
  erro.classList.add("oculto");
  irParaPassoWizard(2);
});

document.getElementById("wizard-proximo-2").addEventListener("click", () => {
  const senha = document.getElementById("setup-senha").value;
  const confirmar = document.getElementById("setup-senha-confirmar").value;
  const pergunta = document.getElementById("setup-pergunta").value.trim();
  const resposta = document.getElementById("setup-resposta").value.trim();
  const erro = document.getElementById("setup-erro");

  let msg = "";
  if (senha.length < 4) msg = "A senha precisa ter pelo menos 4 caracteres.";
  else if (senha !== confirmar) msg = "As senhas digitadas não são iguais.";
  else if (!pergunta || !resposta) msg = "Preencha a pergunta e a resposta de segurança.";
  if (msg) {
    erro.textContent = msg;
    erro.classList.remove("oculto");
    return;
  }
  erro.classList.add("oculto");
  irParaPassoWizard(3);
});

document.getElementById("wizard-voltar-2").addEventListener("click", () => irParaPassoWizard(1));
document.getElementById("wizard-voltar-3").addEventListener("click", () => irParaPassoWizard(2));

document.querySelectorAll(".wizard-tema").forEach((b) => {
  b.addEventListener("click", () => {
    aplicarTema(b.dataset.tema);
    document.querySelectorAll(".wizard-tema").forEach((x) => x.classList.toggle("ativo", x === b));
  });
});

document.getElementById("btn-setup-confirmar").addEventListener("click", async () => {
  const senha = document.getElementById("setup-senha").value;
  const pergunta = document.getElementById("setup-pergunta").value.trim();
  const resposta = document.getElementById("setup-resposta").value.trim();
  const erro = document.getElementById("wizard-erro-3");
  try {
    await invoke("configurar_auth", { senha, pergunta, resposta });
  } catch (e) {
    erro.textContent = "Não foi possível salvar a senha. Volte e tente novamente.";
    erro.classList.remove("oculto");
    return;
  }
  try {
    await invoke("salvar_medico_config", {
      nome: document.getElementById("w-nome").value.trim(),
      crm: document.getElementById("w-crm").value.trim(),
      rqe: document.getElementById("w-rqe").value.trim(),
      especialidade: document.getElementById("w-especialidade").value.trim(),
      endereco: document.getElementById("w-endereco").value.trim(),
      telefone: document.getElementById("w-telefone").value.trim(),
      celular: document.getElementById("w-celular").value.trim(),
      cidade: document.getElementById("w-cidade").value.trim(),
      uf: document.getElementById("w-uf").value.trim().toUpperCase(),
    });
  } catch (e) {
    console.error("Falha ao salvar dados do médico no assistente:", e);
  }
  ["setup-senha", "setup-senha-confirmar", "setup-resposta"].forEach((id) => (document.getElementById(id).value = ""));
  liberarAcessoAoApp();
});

document.getElementById("btn-login-entrar").addEventListener("click", async () => {
  const senha = document.getElementById("login-senha").value;
  const ok = await invoke("verificar_senha", { senha });
  const erro = document.getElementById("login-erro");
  document.getElementById("login-senha").value = "";
  if (ok) {
    erro.classList.add("oculto");
    liberarAcessoAoApp();
  } else {
    erro.classList.remove("oculto");
    document.getElementById("login-senha").focus();
  }
});
document.getElementById("login-senha").addEventListener("keydown", (e) => {
  if (e.key === "Enter") document.getElementById("btn-login-entrar").click();
});

document.getElementById("btn-esqueci-senha").addEventListener("click", async () => {
  const pergunta = await invoke("obter_pergunta_seguranca");
  document.getElementById("recuperar-pergunta").textContent = pergunta;
  document.getElementById("recuperar-resposta").value = "";
  document.getElementById("recuperar-erro").classList.add("oculto");
  mostrarEtapaAuth("auth-recuperar");
});
document.getElementById("btn-recuperar-cancelar").addEventListener("click", () => {
  mostrarEtapaAuth("auth-login");
});
document.getElementById("btn-recuperar-confirmar").addEventListener("click", async () => {
  const resposta = document.getElementById("recuperar-resposta").value;
  const ok = await invoke("verificar_resposta_seguranca", { resposta });
  if (ok) {
    document.getElementById("nova-senha-1").value = "";
    document.getElementById("nova-senha-2").value = "";
    document.getElementById("nova-senha-erro").classList.add("oculto");
    mostrarEtapaAuth("auth-nova-senha");
  } else {
    document.getElementById("recuperar-erro").classList.remove("oculto");
  }
});
document.getElementById("btn-nova-senha-confirmar").addEventListener("click", async () => {
  const s1 = document.getElementById("nova-senha-1").value;
  const s2 = document.getElementById("nova-senha-2").value;
  const erro = document.getElementById("nova-senha-erro");
  if (s1.length < 4) {
    erro.textContent = "A senha precisa ter pelo menos 4 caracteres.";
    erro.classList.remove("oculto");
    return;
  }
  if (s1 !== s2) {
    erro.textContent = "As senhas digitadas não são iguais.";
    erro.classList.remove("oculto");
    return;
  }
  await invoke("redefinir_senha", { novaSenha: s1 });
  mostrarToast("Senha redefinida");
  mostrarEtapaAuth("auth-login");
  document.getElementById("login-senha").focus();
});

// Trocar senha (dentro de Dados do médico)
document.getElementById("btn-alterar-senha").addEventListener("click", async () => {
  const atual = document.getElementById("sen-atual").value;
  const nova = document.getElementById("sen-nova").value;
  const erro = document.getElementById("sen-erro");

  if (nova.length < 4) {
    erro.textContent = "A nova senha precisa ter pelo menos 4 caracteres.";
    erro.classList.remove("oculto");
    return;
  }

  const ok = await invoke("alterar_senha", { senhaAtual: atual, novaSenha: nova });
  if (ok) {
    erro.classList.add("oculto");
    document.getElementById("sen-atual").value = "";
    document.getElementById("sen-nova").value = "";
    mostrarToast("Senha alterada");
  } else {
    erro.textContent = "Senha atual incorreta.";
    erro.classList.remove("oculto");
  }
});

// ---------- Início ----------

iniciarPortaoAuth();
inicializarAutocompleteCid();
